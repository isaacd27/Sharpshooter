from Global import *
import pygame

class inv:

    def __init__(self):
        self.itemlist = ["Heart","Red berry Potion","Blue berry Potion"]
        self.selected = 0
        self.font = pygame.font.Font('freesansbold.ttf', 15)
        self.funfont = pygame.font.Font('freesansbold.ttf', 10)

        #end def

    def draw(self,Screen):

        Screen.fill(SILVER)
        y = 10
        for i in range(len(self.itemlist)):
            itemw,itemh = self.font.size(self.itemlist[i])
            text = self.font.render(self.itemlist[i],1,BLACK)


            Screen.blit(text,(20,y))



            if i == self.selected:
                pygame.draw.rect(Screen,ORANGE,(20,y,itemw + 20,itemh),1)



            y += itemh


        pygame.display.flip()




    def buying(self,boo,Screen,guy):

        while not boo:
            self.draw(Screen)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    boo = true

                elif event.type == pygame.KEYDOWN:

                    if event.key == pygame.K_x:
                        boo = true
                    elif event.key == pygame.K_w:
                        if self.selected != 0:
                            self.selected -= 1
                        else:
                            self.selected = len(self.itemlist) - 1
                    elif event.key == pygame.K_s:
                        if self.selected != len(self.itemlist) - 1:
                            self.selected += 1
                        else:
                            self.selected = 0


                    elif event.key == pygame.K_c:

                        if self.itemlist[self.selected] == "Heart":

                            guy.hp += 10
                            del self.itemlist[self.selected]

                        elif self.itemlist[self.selected] == "Red berry Potion":

                            guy.hp -= 1
                            guy.attack += 2

                            del self.itemlist[self.selected]

                        elif self.itemlist[self.selected] == "Blue berry Potion":

                            guy.defense += 1

                        del self.itemlist[self.selected]










    #end shop