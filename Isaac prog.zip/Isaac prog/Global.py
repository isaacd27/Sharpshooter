import spritesheet
import pygame
TILES = []

BLUE = (25,50,255)
BLACK = (0,0,0)
SILVER = (219,228,235)
WHITE = (255,255,255)
RED = (255,0,0)
GREEN = (0,255,0)
ALTBLU = (0,0,255)
YELLOW = (255,255,0)
PURPLE = (255,0,255)
BROWN = (181,101,29)
CYAN = (0,206,209)
blocksize = 32
BEIGE = (200,200,70)
DARKHAKI = (189,183,107)
ORANGE = (255,180,40)
WALKABLE = [0,1,67,62,90,91,118,119,120,146,147,117,116,56,30,84,112,58,92,142,170,619,620,645,646,140,280,168,397,369,425,396,339,399,85,28]
PUSHABLE = [620,28]
ColourS = (BLUE,BLACK,WHITE,RED,GREEN,ALTBLU,YELLOW,PURPLE,CYAN,BEIGE,ORANGE)
START = "C:/Users/RealProgramming4Kids/PycharmProjects/Isaac prog/Important/" #change
#START = "Important/"
Nmap = {"Start": START + "Start(Real).csv", "Forest Village": START + "Forest Village.csv", "LeftFV": START + "FVL.csv", "ForestStartClose": START + "FE.csv",
        "TempleOut": START + "FTE.csv", "TemIn1": START + "TE.csv", "TemRi": START + "TR.csv", "TemIn2": START + "TE2.csv", "TemL": START + "Tl.csv", "TemIn3": START + "TE3.csv",
        "TemBoss": START + "TB.csv", "TemOut2": START + "FTE2.csv","ForStaOp": START + "FE2.csv", "LeftFV2": START + "FVL2.csv", "ForShop": START + "FSHOP.csv",
        "LFVCave": START + "FSCAVE.csv","FV2": START + "FV.csv"}
AMap = {("Start",7,18) : ("Forest Village",7,5),
        ("Forest Village",7,4): ("Start",7,17),
        ("Forest Village",0,8): ("LeftFV",18,8),
        ("LeftFV",19,8): ("Forest Village",1,8),
        ("LeftFV",0,8): ("ForestStartClose",18,8),
        ("ForestStartClose",19,8): ("LeftFV",1,8),
        ("ForestStartClose",9,0): ("TempleOut",9,18),
        ("TempleOut",9,19): ("ForestStartClose",8,0),
        ("TempleOut",9,11): ("TemIn1",10,18),
        ("TemIn1",10,19): ("TempleOut",9,12),
        ("TemIn1",19,11): ("TemRi",1,11),
        ("TemRi",0,11): ("TemIn2",18,11),
        ("TemIn2",19,11): ("TemRi",1,11),
        ("TemIn2",0,11): ("TemL",9,1),
        ("TemL",9,0): ("TemIn3",1,11),
        ("TemIn3",0,11):("TemL",9,1),
        ("TemIn3",9,0): ("TemBoss",10,18),
        ("TemBoss",9,0): ("TemOut2",9,9),
        ("TemOut2",9,19):("ForStaOp",9,1),
        ("ForStaOp",9,0):("TemOut2",9,18),
        ("ForStaOp",19,8):("LeftFV2",1,8),
        ("LeftFV2",0,8): ("ForStaOp",18,8),
        ("LeftFV2",14,5):("ForShop",9,18),
        ("ForShop",9,19):("LeftFV2",14,6),
        ("LeftFV2",8,1): ("LFVCave",9,18),
        ("LFVCave",9,19): ("LeftFV2",8,2),
        ("LeftFV2",19,8): ("FV2",1,8),
        ("FV2",0,8): ("LeftFV2",18,8)


        } #dictionarya
Carea = "LeftFV2"
Colour = BEIGE
true,false,none = True,False,None

font = none
HSfont = None
nextf = None
funfont = None
def init():
        global font,HSfont,nextf,funfont
        pygame.init()
        font = pygame.font.Font('freesansbold.ttf', 20)
        HSfont = pygame.font.Font('freesansbold.ttf', 20)
        nextf = pygame.font.Font('freesansbold.ttf', 30)
        funfont = pygame.font.Font('freesansbold.ttf', 10)
        TILES[:] = spritesheet.loadtiles("C:/Users/RealProgramming4Kids/PycharmProjects/Isaac prog/Important/" + "Tile.png")
    #end def