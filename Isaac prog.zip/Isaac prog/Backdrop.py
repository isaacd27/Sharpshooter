from Global import *
import csv

class Backdrop:

    def __init__(self):

        self.Tilemap = []


    #end def
    def load(self,Area):

        file = open(Area,'r')
        csvread = csv.reader(file,delimiter = ',')
        self.Tilemap = []
        for row in csvread:
            Row = list(map(int,row))
            self.Tilemap.append(Row)

            #end for
        file.close()




    def draw(self,Screen):
        for y in range(len(self.Tilemap)):
            for x in range(len(self.Tilemap[y])):
                tile = self.Tilemap[y][x]

                Screen.blit(TILES[tile],(x*32,y*32))



                #end for
            #end for



        #end def

    def stand(self,Xpos,Ypos):
        Xpos = (Xpos + blocksize//2)//blocksize
        Ypos = (Ypos + blocksize//2)//blocksize

        if Ypos >= len(self.Tilemap):
            return false
        elif Xpos >= len(self.Tilemap[Ypos]):
            return false
        else:
            return self.Tilemap[Ypos][Xpos] in WALKABLE

        #end def

    def Push(self,Xpos,Ypos):
        Xpos = (Xpos + blocksize//2)//blocksize
        Ypos = (Ypos + blocksize//2)//blocksize

        if Ypos >= len(self.Tilemap):
            return false
        elif Xpos >= len(self.Tilemap[Ypos]):
            return false
        else:
            return self.Tilemap[Ypos][Xpos] in PUSHABLE


    def gettile(self,Xpos,Ypos):
        Xpos = (Xpos + blocksize // 2) // blocksize
        Ypos = (Ypos + blocksize // 2) // blocksize

        if Ypos >= len(self.Tilemap):
            return false
        elif Xpos >= len(self.Tilemap[Ypos]):
            return false
        else:
            return self.Tilemap[Ypos][Xpos]
    #end Backdrop