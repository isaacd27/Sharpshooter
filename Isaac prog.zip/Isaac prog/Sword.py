from Global import *
import pygame
time = [0]

class Sword:

    def __init__(self,p):


        self.Xpos = p.Xpos - 10
        self.Ypos = p.Ypos + (25/2)
        self.width = 10
        self.height = 5
        self.stabbing = 0
        #end def


    def draw(self,Screen,attack,p):


        if self.stabbing > 0:
            self.stabbing -= 1

        if attack < 5:
            pass
        else:
            mod = 0
            if self.stabbing > 0:
                mod = 5
            if p.PrevX > p.Xpos:
                pygame.draw.rect(Screen,SILVER,[p.Xpos - 10 - mod,p.Ypos + (25/2),self.width,self.height],0) #left
                self.Xpos = p.Xpos - 10 - mod
                self.Ypos = p.Ypos + (25/2)
            elif p.PrevX < p.Xpos:
                pygame.draw.rect(Screen, SILVER, [p.Xpos + 25 + mod, p.Ypos + (25 / 2), self.width, self.height], 0)  # right
                self.Xpos = p.Xpos + 25 + mod
                self.Ypos = p.Ypos + (25/2)
            elif p.PrevY > p.Ypos:
                pygame.draw.rect(Screen,SILVER,[p.Xpos + 10,p.Ypos - 10 - mod,self.height,self.width],0) #up
                self.Xpos = p.Xpos + 10
                self.Ypos = p.Ypos - 10 - mod
            elif p.PrevY < p.Ypos:
                pygame.draw.rect(Screen, SILVER, [p.Xpos + 10, p.Ypos + 25 + mod, self.height, self.width], 0)
                self.Xpos = p.Xpos + 10
                self.Ypos = p.Ypos + 25 + mod

    def forsword(self):
        self.stabbing = 25




        #end def
    def stab(self,Thing,attack):
        if self.Xpos + self.width >= Thing.Xpos and self.Xpos <= Thing.Xpos + Thing.size:
            if self.Ypos + self.height >= Thing.Ypos and self.Ypos <= Thing.Ypos + Thing.size:



                    Thing.hp -= attack


                #end if


    #end Sword