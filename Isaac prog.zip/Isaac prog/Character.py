import pygame
time = [0]

WHITE = (255,255,255)
GREEN = (0,255,0)
class Character:
    def __init__(self,Xpos,Ypos,health):

        self.Xpos = Xpos
        self.Ypos = Ypos
        self.hp = 10
        self.health = health
        self.PrevX = 0
        self.PrevY = 0
        self.size = 25
        self.equipped = ""
        #end def
    def Hit(self,OXp,OYp,OSizeW,OSizeH,Attack,Defense,OHP):

        if OHP != 0:
            if self.Xpos + self.size >= OXp  and self.Xpos <= OXp + OSizeW:
                if self.Ypos + self.size >= OYp and self.Ypos <= OYp + OSizeH:
                    time[0] += 1

                    if time[0] % 60 == 0:
                        self.hp -= (Attack - Defense)
               # print(self.hp)
                if self.hp < 0:
                    self.hp = 0
                    #end if
                #end if
        #end if





#END DEF
    def move(self,Xmove,Ymove,Back):
        SignX = -1 if Xmove < 0 else 1
        SignY = -1 if Ymove < 0 else 1

        self.PrevX = self.Xpos
        self.PrevY = self.Ypos

        if Xmove == 0:
            SignX = 0

        if Ymove == 0:
            SignY = 0
        x,y =self.Xpos + Xmove + 25 // 2 * SignX, self.Ypos + Ymove + 25 // 2 * SignY

        x2,y2 = self.Xpos - Xmove + 25//2* SignX, self.Ypos - Ymove + 25 //2 * SignY

        if x <= 640 and x2 >= 0 and y <= 640 and y2 >= 1:
            if Back.stand(x,y):
                self.Xpos += Xmove
                self.Ypos += Ymove
                #end if
            #end if
        #end def

    def draw(self,Screen):

        pygame.draw.rect(Screen,WHITE,[self.Xpos,self.Ypos,25,25],0)
        pygame.draw.rect(Screen,GREEN,[self.Xpos,self.Ypos,int(self.hp/self.health*25),4],0)
        #end def




#end Character