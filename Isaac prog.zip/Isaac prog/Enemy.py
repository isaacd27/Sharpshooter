import pygame
from Global import *
import random
Timer = [0]

class Enemey:


    def __init__(self,Xpos,Ypos,size,name,health):
#,filename
        self.Xpos = Xpos
        self.Ypos = Ypos
        self.size = size
        self.Name = name
        self.health = health
        self.Attack = 0
        self.behaviour = "N/A"
        self.hp = 0
        self.type()
        self.timer = 0
        #self.sprite = pygame.image.load(filename)
        #end def

    def draw(self,Screen):

        if self.hp < 0:
            self.hp = 0

        if self.hp > 0:
            if self.Name == "BRBear":
                #Screen.blit(self.Xpos,self.Ypos,self.sprite)
                pygame.draw.rect(Screen,BROWN,[self.Xpos,self.Ypos,self.size,self.size],0)
            elif self.Name == "Tguard":
                pygame.draw.rect(Screen,DARKHAKI,[self.Xpos,self.Ypos,self.size,self.size],0)
            elif self.Name == "BLBear":
                pygame.draw.rect(Screen, BLACK, [self.Xpos, self.Ypos, self.size, self.size], 0)
            elif self.Name == "Blob":
                pygame.draw.rect(Screen, BLACK, [self.Xpos, self.Ypos, self.size, self.size], 0)
            #end if


    #end draw

    def type(self):

        if self.Name == "BRBear":
            self.Attack = 5
            self.behaviour = "Bear"
            self.hp = 10
        elif self.Name == "Tguard":
            self.Attack = 1
            self.behaviour = "Aggresive"
            self.hp = 10
        elif self.Name == "BLBear":
            self.Attack = 6
            self.behaviour = "Aggresive"
            self.hp = 10

        elif self.Name == "Blob":
            self.Attack = 6
            self.behaviour = "Wander"
            self.hp = 13

        else:
            pass


    #end def


    def move(self,Back):

        if self.behaviour == "Bee":

            Xmove = random.randint(-2,2)

            if Xmove == 0:
                Ymove = random.randint(-2,2)
                SignX = 0
                if Ymove > 0:
                    SignY = 1
                elif Ymove < 0:
                    SignY = -1
                else:
                    SignY = 0

            elif Xmove > 0:
                Ymove = 0
                SignY = 0
                SignX = 1
            else:
                Ymove = 0
                SignY = 0
                SignX = -1

                #end if

            if self.Xpos + Xmove <= 800 and self.Xpos - Xmove >= 0 and self.Ypos + Ymove <= 600 and self.Ypos - Ymove >= 1:
                if Back.stand(self.Xpos + Xmove + 25 // 2 * SignX, self.Ypos + Ymove + 25 // 2 * SignY):
                    self.Xpos += Xmove
                    self.Ypos += Ymove

            #end if
        elif self.behaviour == "Bear":

            Timer[0] += 1

            #print (self.Xpos,self.Ypos)

            if Timer[0] % 60 == 0:
                Ymove = 0
                Xmove = 2
                SignX = 1
                SignY = 0
                if Back.stand(self.Xpos + Xmove + 25 // 2 * SignX,self.Ypos + Ymove + 25 // 2 * SignY):
                    self.Xpos += Xmove
                elif Back.stand(self.Xpos + Xmove + 25 // 2 * - SignX,self.Ypos + Ymove + 25 // 2 * - SignY):
                    self.Xpos -= Xmove
            elif Timer[0] % 90 == 0:
                SignY = 1
                SignX = 0
                Ymove = 2
                Xmove = 0
                if Back.stand( self.Xpos + Xmove + 25 // 2 *  SignX,self.Ypos + Ymove + 25 // 2 * SignY):
                    self.Ypos += Ymove
                elif Back.stand(self.Xpos + Xmove + 25 // 2 * - SignX, self.Ypos + Ymove + 25 // 2 * - SignY):
                    self.Ypos -= Ymove







        elif self.behaviour == "Stand":
            pass




        #end move

    def Amove(self,Player,Back):
        self.timer += 1
        Xmove = 0
        Ymove = 0
        SignX = 0
        SignY = 0
        if self.Ypos < Player.Ypos:
            Ymove = 1
            SignY = 1
        elif self.Ypos > Player.Ypos:
            Ymove = -1
            SignY = -1
        else:
            SignY = 0
            if self.Xpos < Player.Xpos:
                Xmove = 1
                SignX = 1
            elif self.Xpos > Player.Xpos:
                Xmove = -1
                SignX = -1
            else:
                Xmove =0
                SignX =0
                #end if
            #end if
        if self.timer % 60 == 0:
            if Back.stand(self.Xpos + Xmove + 25 // 2 * SignX, self.Ypos + Ymove + 25 // 2 * SignY):
                self.Xpos += Xmove
                self.Ypos += Ymove



        #end def


    def wmove(self,X1,Y1,X2,Y2):

        self.timer += 1
        Xmove = 0
        Ymove = 0
        if self.timer % 60 == 0:

            if self.Ypos == Y1:

                if X2 > self.Xpos:
                    Xmove = 1
                elif X2 < self.Xpos:
                    Xmove = -1


            if self.Xpos == X2:


                if Y2 > self.Ypos:
                    Ymove = 1
                elif Y2 < self.Ypos:
                    Ymove = -1


            if self.Ypos == Y2:

                if X1 > self.Xpos:
                    Xmove = 1
                elif X1 < self.Xpos:
                    Xmove = -1

            if self.Xpos == X1:

                if Y1 > self.Ypos:
                    Ymove = 1
                elif Y1 < self.Ypos:
                    Ymove = -1

            #End if

        self.Xpos += Xmove
        self.Ypos += Ymove



#end enemey