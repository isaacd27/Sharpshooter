from Global import *
import pygame

class NPC:



    def __init__(self,Xpos,Ypos,filename):

        self.Xpos = Xpos
        self.Ypos = Ypos
        self.pic = filename
        self.font = pygame.font.Font('freesansbold.ttf', 15)

    def draw(self,Screen,text):
        x,y = 0,400

        pygame.draw.rect(Screen,ALTBLU,(x,y,640,100),0)
        pygame.draw.rect(Screen,WHITE, (x, y, 640, 100), 1)

        #w,h = font.size(text)

        pygame.display.flip()


    def talk(self,boo,area,Screen):

        while not boo:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    boo = true
                    #end if

            #end for
        if area == "LeftFV2":
            text = self.font.render("Test",1,WHITE)

        self.draw(Screen, text)
        #end while
