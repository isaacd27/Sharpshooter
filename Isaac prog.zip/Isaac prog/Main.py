from Global import *
import pygame
from Character import Character
from spritesheet import spritesheet
from Enemy import Enemey
from Backdrop import Backdrop
from Block import Block
from Key import Key
from Sword import Sword
from Boss import Boss
from Projectile import Proj
from Shop import shop
from Inv import inv
from NPC import NPC
cutscene = 0
rewarded = false
shopreward = false
buying = false
Scene = 0

Money = 0
Puzzle = false

Done = False
Size = (640,640)
Screen = pygame.display.set_mode(Size)
init()

funfont = pygame.font.Font('freesansbold.ttf', 10)
health = 10
defense = 5
attack = 5
guy = Character(400,300,health)
sword = Sword(guy)
brownbear = Enemey(3*32,7*32,25,"BRBear",10 )
blackbear = Enemey (3*32,7*32,25,"BLBear",10 )
blob = Enemey(3*32,7*32,25,"Blob",13)
Guard1 = Enemey(16*32,10*32,25,"Tguard",10)
Guard2 = Enemey (16*32,9*32,25,"Tguard",10)
Gooey = Boss (8*32,8*32,20,5,"GG")
James = NPC(0,0,"hi")
key = Key(14*32,8*32)
wBlock = Block(6*32,7*32,"Wood")
Shop = shop()
inventory = inv()
back = Backdrop()
back.load(Nmap[Carea])

upcount = 0
rightcount = 0
leftcount = 0
downcount = 0


enlist = [brownbear,Guard1,Guard2,Gooey,blackbear]

if __name__ == "__main__":
    init()
    while not Done:
        keys = pygame.key.get_pressed()

        if keys[pygame.K_a]:
            leftcount += 1
            if leftcount %60 == 0:
                guy.move(-5, 0,back)

                #end if
        elif keys[pygame.K_s]:
            downcount += 1
            if downcount %60 == 0:
                guy.move(0,5,back)

                #end if
        elif keys[pygame.K_d]:
            rightcount += 1
            if rightcount %60 == 0:
                guy.move(5,0,back)

                #end if

        elif keys[pygame.K_w]:
            upcount += 1
            if upcount %60 ==0:
                guy.move(0,-5,back)

                #end





            #end if


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                Done = true
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_z:
                    sword.forsword()
                    for enemey in enlist:

                        sword.stab(enemey,attack)
                        print(attack)

                elif event.key == pygame.K_x and Carea == "ForShop":

                    Shop.buying(buying,Money,Screen,inventory)

                    back.load(Nmap[Carea])
                elif event.key == pygame.K_x and Carea != "ForShop":

                    #inventory.buying(buying,Screen,guy)

                    James.talk(buying,Carea,Screen)

                    back.load(Nmap[Carea])






                    #end if






                #endif
            #end for
            Xpos = (guy.Xpos + blocksize // 2) // blocksize
            Ypos = (guy.Ypos + blocksize // 2) // blocksize
            #print (Xpos,Ypos)
            if (Carea,Xpos,Ypos) in AMap and cutscene == 0:
               # print (Carea)
                Carea,Xpos,Ypos = AMap[(Carea,Xpos,Ypos)]
                back.load(Nmap[Carea])
                guy.Xpos = Xpos*blocksize
                guy.Ypos = Ypos*blocksize
                rewarded = false

                # end if
                #end if


        if Carea == "TemRi" and Puzzle == false:
            cutscene = 1

        elif Carea == "TemRi" and Puzzle == true:
            cutscene = 0
            key.Active = true

            if back.gettile(guy.Xpos, guy.Ypos) == 619:

                back.Tilemap[12][14] = 616
                attack = 5

        elif Carea == "TemIn2":
            Puzzle = false




        if Carea == "TemRi" and wBlock.Xpos + 1 == 14* 32:
            Puzzle = true





        #end if




        Screen.fill(Colour)

        back.draw(Screen)
        if Carea == "ForestStartClose":

            brownbear.draw(Screen)
            brownbear.move(back)

            guy.Hit(brownbear.Xpos,brownbear.Ypos,25,25,5,defense,brownbear.hp)


        elif Carea == "TemL":

            Guard1.draw(Screen)
            Guard2.draw(Screen)

            Guard1.Amove(guy,back)
            Guard2.Amove(guy,back)

            guy.Hit(Guard1.Xpos,Guard1.Ypos,25,25,1,defense,Guard1.hp)
            guy.Hit(Guard2.Xpos, Guard2.Ypos, 25, 25, 1, defense,Guard2.hp)





            if Guard1.hp != 0 and Guard2.hp != 0:
                cutscene = 1

        elif Carea == "TemBoss":
            Gooey.draw(Screen)
            Gooey.move(guy,Screen)


            print(Gooey.hp)

            if Gooey.hp != 0:
                cutscene = 1
            else:
                cutscene = 0
                back.Tilemap[0][9] = 645
                if rewarded == false:
                    Money += 10
                    rewarded = true

        elif Carea == "ForStaOp":

            blackbear.Amove(guy,back)
            blackbear.draw(Screen)

            guy.Hit(blackbear.Xpos,blackbear.Ypos,25,25,6,defense,blackbear.hp)



        if Carea == "LFVCave":

            if back.gettile(guy.Xpos,guy.Ypos) == 85:

                back.Tilemap[4][9] = 672

                if shopreward == false:
                    Money += 100

                    shopreward = true

            #end if

            #end if


        guy.draw(Screen)
        key.draw(Screen,Puzzle)
        sword.draw(Screen, attack,guy)

        funtext = funfont.render("$: " + str(Money),1,BLACK)
        Screen.blit(funtext,(0,0))






            #end for



        if Carea == "TemL" and Guard1.hp == 0 and Guard2.hp == 0 and defense == 0:

            back.Tilemap[0][9] = 645
            back.Tilemap[13][10] = 617


        if Carea == "TemL" and back.Tilemap[13][10] == 617:

            if back.gettile(guy.Xpos, guy.Ypos) == 619:
                back.Tilemap[13][10] = 616
                defense = 5
                cutscene = 0


            #end if


        if Carea == "TemRi":

            wBlock.draw(Screen)
            wBlock.push(guy,back)

        #end if
        pygame.display.flip()

        #end while
    #end if