<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="Tile" tilewidth="32" tileheight="32" tilecount="784" columns="28">
 <image source="../../Downloads/Tile.png" width="896" height="896"/>
</tileset>
