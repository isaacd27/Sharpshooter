import pygame
from Global import *


class Key:


    def __init__(self,Xpos,Ypos):
        self.Xpos = Xpos
        self.Ypos = Ypos

    #end def


    def draw(self,Screen,active):


        if active == true:


            pygame.draw.rect(Screen,YELLOW,[self.Xpos,self.Ypos,10,10],0)

            #end if






    #end key