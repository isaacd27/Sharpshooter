from Global import *
from math import sin,cos
import pygame

class Proj:


    def __init__(self,thing,direction,attack,angle):

        self.Xpos = thing.Xpos
        self.Ypos = thing.Ypos
        self.direction = direction
        self.a = angle
        self.dam = attack
        self.timer = 0
        #end def


    def move(self,target):

        Xmove = self.direction * cos(self.a)
        Ymove = self.direction * sin(self.a)

        self.timer += 1

        if self.timer % 60 == 0:
            self.Xpos += Xmove
            self.Ypos += Ymove


    def draw(self,Screen):

        pygame.draw.rect(Screen,RED,[self.Xpos,self.Ypos,10,10],0)



    #end Proj