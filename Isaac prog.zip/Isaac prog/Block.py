from Global import *
import pygame

class Block:

    def __init__(self,Xpos,Ypos,Material):
        self.Xpos = Xpos
        self.Ypos = Ypos
        self.Type = Material




    #end def

    def push(self,Player,Back):

        if self.Xpos + 32 >= Player.Xpos and self.Xpos <= Player.Xpos + 25:
            if self.Ypos + 32 >= Player.Ypos and self.Ypos <= Player.Ypos + 25:

                Xmove = Player.Xpos - Player.PrevX



                Ymove = Player.Ypos - Player.PrevY

                SignX = -1 if Xmove < 0 else 1
                SignY = -1 if Ymove < 0 else 1

                if Xmove == 0:
                    SignX = 0

                if Ymove == 0:
                    SignY = 0


                x, y = self.Xpos + Xmove + 25 // 2 * SignX, self.Ypos + Ymove + 25 // 2 * SignY

                x2, y2 = self.Xpos - Xmove + 25 // 2 * SignX, self.Ypos - Ymove + 25 // 2 * SignY

                if x <= 800 and x2 >= 0 and y <= 600 and y2 >= 1:
                    if Back.Push(x, y):
                        self.Xpos += Xmove
                        self.Ypos += Ymove
                        # end if
                    # end if



                #end if
        #end def
    def draw(self,Screen):

        if self.Type == "Wood":

            pygame.draw.rect(Screen,BROWN,[self.Xpos,self.Ypos,32,32],0)



            #end if



    #end box