from Global import *
from Projectile import Proj
import pygame
from math import atan2


class Boss:

    def __init__(self,Xpos,Ypos,hp,attack,name):
        self.Xpos = Xpos
        self.Ypos = Ypos
        self.hp = hp
        self.dam = attack
        self.name = name
        self.proj = []
        self.timer = 0
        self.size = 25
        #end def

    def draw(self,Screen):

        if self.hp < 0:
            self.hp = 0
            #end if


        if self.hp > 0:
            if self.name == "GG":

                pygame.draw.rect(Screen,SILVER,[self.Xpos,self.Ypos,25,25],0)

                #end if
            #end if




        #end def





    def move(self,player,Screen):


        if self.name == "GG":

            if self.timer %240 == 0 and len(self.proj) <= 5 and self.hp != 0:

                self.proj.append(Proj(self,5,6,atan2(player.Ypos - self.Ypos,player.Xpos - self.Xpos )))
        i = 0
        while i < len(self.proj):
            if self.proj[i].Xpos <= 640 and self.proj[i].Xpos >= 0 and self.proj[i].Ypos <= 640 and self.proj[i].Ypos >= 1:
                self.proj[i].move(player)
                self.proj[i].draw(Screen)
                player.Hit(self.proj[i].Xpos,self.proj[i].Ypos,10,10,6,5,1)
            else:
                del self.proj[i]
                i -= 1
                #end if

            i += 1

        else:
            pass



#end boss