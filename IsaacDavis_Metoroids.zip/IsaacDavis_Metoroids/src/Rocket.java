
import java.awt.*;

/*
 * Here comes the text of your license
 * It was made by Isaac Davis
 *  not RP4K
 */

/**
 *
 * @author RealProgramming4Kids
 */
public class Rocket extends Vectorsprite {
    
    public Rocket(double x, double y, double a){
     shape = new Polygon();
    shape.addPoint(0,3);
         shape.addPoint(-1,-1);
         shape.addPoint(1,-1);
         //shape.addPoint(0,0);
     
       
          drawshape = new Polygon();
         drawshape.addPoint(0,3);
         drawshape.addPoint(-1,-1);
         drawshape.addPoint(1,-1);
         //drawshape.addPoint(0,0);
         active = true;
         xpostion = x;
         ypostion = y;
         angle = a;
         ROCKETS = 10;
       yspeed = ROCKETS*Math.sin(angle - Math.PI/2);
    xspeed = ROCKETS*Math.cos(angle - Math.PI/2);
        }
    
}
