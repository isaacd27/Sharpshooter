/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.Timer;
import java.applet.AudioClip;
/**
 *
 * @author isaacdavis
 */
public class Metoroids extends Applet implements KeyListener,ActionListener { 
    int x1,x2,y1,y2;
    Image offscreen;
    Graphics offg;
    Shootmcship ship;
    Timer timer;
    boolean upkey, MANUP;
            boolean rightkey,downkey;
            boolean leftkey,spacekey,shop,gamewon,tribuy,rockbuy,armor1buy,armor2buy,armor3buy,armor4buy,gold,ruby,diamond,magnetbuy;
            boolean minibuy,manbuy,supermanbuy = false;
            int livesbuy;
            Asteriods rock;
            ArrayList<Asteriods> asteriodlist;
            ArrayList<Weapon> bulletlist;
            ArrayList<Debris> debrislist;
            ArrayList<Rocket> rocketlist;
            int lives = 5;
            int score;
            int monies;
            Polygon drawshape;
            AudioClip laser,shiphit,asteriodhit,thruster,music;
             Color GOLD = new Color(255,233,0);
             Scanner reader = new Scanner(System.in);
             String cheat;
int[] x,y;

  

    public void init() {
     this.setSize(900,600); 
  
    
    x = new int[3];
    x[0] = 15;
    x[1] = 0;
    x[2] =30;
    
    y = new int[]{0,30,30};
    drawshape = new Polygon();
   ship = new Shootmcship();
    rock = new Asteriods();
    asteriodlist = new ArrayList();
    bulletlist = new ArrayList();
    debrislist = new ArrayList();
    rocketlist = new ArrayList();
      Color GOLD = new Color(255,233,0);
    laser = getAudioClip(getCodeBase(),"laser80.wav");
      thruster = getAudioClip(getCodeBase(),"thruster.wav");
        shiphit = getAudioClip(getCodeBase(),"explode1.wav");
          asteriodhit = getAudioClip(getCodeBase(),"explode0.wav");
          music = getAudioClip(getCodeBase(),"Star Commander1.wav");
    this.addKeyListener(this);
    music.loop();
    timer = new Timer(20,this);
    offscreen = createImage(this.getWidth(),this.getHeight());
    offg = offscreen.getGraphics();
        for (int i = 0; i < 6; i++) {
            
        
    asteriodlist.add(new Asteriods());
        }
    }
      public void start(){
    timer.start();
}
      
      public void stop(){
          timer.stop();
      }
   
public void paint(Graphics g){
 
   offg.setColor(Color.BLACK);
    offg.fillRect(0,0,900,600);
 if (shop == false && gamewon == false ||shop && gamewon == false|| shop == false && gamewon ){
 gamewon = false;
     // g.setColor(Color.CYAN);
  // g.drawPolygon(x,y,x.length);
    if (ship.Body == "default"){
  offg.setColor(Color.GREEN);
    }
    if (ship.Body == "armored"){
        offg.setColor(Color.BLUE);
    }
    if(ship.Body == "iron"){
        offg.setColor(Color.LIGHT_GRAY);
    }
    
    if(ship.Body == "steel"){
        offg.setColor(Color.GRAY); 
    }
    
    if(ship.Body == "reinforced"){
        offg.setColor(Color.WHITE);
    }
    
    if(ship.Body == "gold"){
    
        offg.setColor(GOLD);
    }
 
 if (ship.Body == "ruby"){
     offg.setColor(Color.RED);
 }
 
 if (ship.Body == "diamond"){
     offg.setColor(Color.CYAN);
 }
 
 if (ship.Body == "pink"){
     offg.setColor(Color.PINK);
 }
    if (ship.active){
    ship.paint(offg);
   
     }
     if (ship.lives < 1){
        ship.active = false;
        offg.setColor(Color.white);
        monies = monies/2;
        offg.drawString("You are literally the worst, go to the shop with half your moneys.",250,300);
        if(shop == false){
          shopreset();
           if (asteriodlist.isEmpty() == true){
    for (int i = 0; i < 6; i++) {
            
        
    asteriodlist.add(new Asteriods());
        }
       }
    else if (asteriodlist.isEmpty()== false){
           asteriodlist.removeAll(asteriodlist);
           for (int i = 0; i < 6; i++) {
            
        
    asteriodlist.add(new Asteriods());
        }
           ship.lives = 5;
           
       }
        }
    }
   if( MANUP == false){
     offg.setColor(Color.white);
   }
   else{
       offg.setColor(Color.MAGENTA);
   }
      for (int i = 0; i < asteriodlist.size(); i++) {
            asteriodlist.get(i).paint(offg);
            if(ship.Body == "pink"){
                offg.drawString("Insecure much?",(int)asteriodlist.get(i).xpostion,(int)asteriodlist.get(i).ypostion);
                
            }
            
        }
      for (int i = 0; i < bulletlist.size(); i++) {
        bulletlist.get(i).paint(offg);
    }
      offg.setColor(Color.red);
      for (int i = 0; i < rocketlist.size(); i++) {
        rocketlist.get(i).paint(offg);
    }
      offg.setColor(Color.white);
      if (asteriodlist.isEmpty()){
          offg.drawString("YOU ARE THE BEST, YOU CAN ENTER THE SHOP NOW!",250,300);
            if (shop == false){
          shopreset();
            }
      }
     if (ship.Body != "pink"){
              offg.drawString("lives: " + ship.lives,0,600);
     }
     else{
         offg.setColor(Color.PINK);
         offg.drawString("MEN HAVE 0 +  " + ship.lives + " LIVES",0,600);
     }
     
      offg.setFont(new Font (offg.getFont().getFontName(),Font.PLAIN,16));
      offg.drawString(""+ score,300,20);
      
      offg.setColor(Color.YELLOW);
      for (int i = 0; i < debrislist.size(); i++) {
        debrislist.get(i).paint(offg);
    }
 }
   offg.setColor(Color.YELLOW);
      offg.drawString("Moneys: " + monies, 400,30);
     if(shop && gamewon){
       offg.drawString("Lives: 4000 monies (p) Bought:" + livesbuy,0,67);
         offg.setColor(Color.YELLOW);
         if (rockbuy == false){
      offg.drawString("Metoriod bombs: 400 monies (b)", 300,50);
         }
         else{
             offg.setColor(Color.GREEN);
             offg.drawString("SOLD: EXPLOSVIE BOMBS", 300,50);
         }
         offg.setColor(Color.YELLOW);
         if(tribuy == false){
      offg.drawString("Money time extender: 600 monies(t)", 570,50);
         }
         else{
              offg.setColor(Color.GREEN);
             offg.drawString("SOLD: TIME MACHINE", 570,50);
         }
          offg.setColor(Color.YELLOW);
         /** 67 + 17 
         * 77 + 7
* = 84
*/
         if(minibuy == false){
      offg.drawString("Useless but expensive: 100,000 (u)", 300 - 270,50);
      offg.setColor(GOLD);
      drawshape = new Polygon();
         drawshape.addPoint(30,-25 +84 );
         drawshape.addPoint(-15 + 30,10 + 84);
         drawshape.addPoint(45,10 + 84);
         offg.drawPolygon(drawshape);
       //crown draw code
     }
         else{
              offg.setColor(Color.GREEN);
              offg.drawString("SOLD: OLD CROWN", 300 - 270,50);
         }
         offg.setColor(Color.YELLOW);
         if (armor1buy && manbuy == false){
             offg.drawString("MANLIEST body: 69 monies (4)", 480,84);
             
         }
         else if (manbuy){
             offg.setColor(Color.GREEN);
             offg.drawString("SOLD: LEAD PINK PAINT(4)", 480, 84);
         }
         offg.setColor(Color.PINK);
         if (manbuy && supermanbuy == false){
             offg.drawString("Manly mode: Infinty*69 monies ($)",300,84 + 17);
       //  }
      //   else if (supermanbuy){
          //   offg.setColor(Color.GREEN);
           //  offg.drawString("SOLD: MAGENTA PAINT(5)",300,84 + 17);
         }
         // 300 - 270 = 30
          offg.setColor(Color.YELLOW);
         if (ship.Body == "default"){
      offg.drawString("Armored body: 500 monies (i)",300,67);
         }
        if (ship.Body != "pink"){
         if (ship.Body != "default" && armor1buy && armor2buy == false){
             offg.drawString("Iron body: 600 monies (i)",300,67);
         }
         if(ship.Body != "armored" && ship.Body != "default" && armor2buy && armor3buy == false){
             offg.drawString("Steel body: 700 monies (i)",300,67);
         }
          if (armor4buy == false && armor3buy){
             offg.drawString("Reinforced Body: 800 monies(i)",300,67);
             }
         if (ship.Body == "steel" ||ship.Body == "gold" || ship.Body == "reinforced"){
            
            if (gold == false){
             offg.drawString("Golden Body 1000 monies (o)",600,67);
            }
             if (armor4buy){
                 offg.drawString("SOLD: PLATING (2)",300,67);
             }
         }
         }
        else{
            offg.setColor(Color.PINK);
            offg.drawString("Real men need no armor",300,67);
        }
        if (ship.Body != "pink" && armor3buy){
         offg.setColor(Color.YELLOW);
         if (gold && ruby == false){
              offg.drawString(" Ruby Body: 2000 monies (o)",600,67);
         }
         
         if (ruby && diamond == false){
             offg.drawString("diamond Body: 10,000 monies (o)",600,67);
         }
         
         if (diamond){
             offg.drawString("SOLD: DIAMONDS (1)",600,67);
         }
        }
        else if (ship.Body == "pink" && armor3buy){
            offg.setColor(Color.PINK);
            offg.drawString("Real men don't need money",600,67);
        }
        offg.setColor(Color.YELLOW);
         if (magnetbuy == false){
             offg.drawString("Magnet: 3000 monies (m)",300,84);
         }
         else if (magnetbuy){
             offg.setColor(Color.GREEN);
             offg.drawString("SOLD: MAGNET",300,84);
         }
         offg.setColor(Color.YELLOW);
         
        offg.drawString("k to exit shop",0,600);
     }
    g.drawImage(offscreen,0,0,this);
    
    repaint();
 
             
              
          
}
public void update(Graphics g){
    paint(g);
}

public void keyPressed(KeyEvent e){
    if (e.getKeyCode() == KeyEvent.VK_D){ 
      // ship.angle += 0.4;
   // ship.accelerate();
   rightkey = true;
    }
    if (e.getKeyCode() == KeyEvent.VK_A) {
        //ship.angle -= 0.4;
   // ship.accelerate();
   leftkey = true;
    }
    if (e.getKeyCode() == KeyEvent.VK_W) {
      //ship.yspeed -= 3;
      //ship.accelerate();
      upkey = true;
      thruster.loop();
    }
     if (e.getKeyCode() == KeyEvent.VK_S) {
     thruster.loop();
     downkey = true;
   }
     
     if (e.getKeyCode() == KeyEvent.VK_SPACE){
         spacekey = true;
     }
     
   //  if (e.getKeyCode() == KeyEvent.VK_1){
  //       ship.weapon = "trishot";
   //  }
     
   //  if (e.getKeyCode() == KeyEvent.VK_2){
   //      ship.weapon = "rocket";
   //  }
    if (e.getKeyCode() == KeyEvent.VK_Y){
        shop = true;
    }
     if (e.getKeyCode() == KeyEvent.VK_N){
         shop = false;
     }
     
     if (e.getKeyCode() == KeyEvent.VK_Z){
        
        
         //&& shop && gamewon && monies >= 400) || 
        
        
        
        

         ship.weapon = "trishot";
        
        // if(tribuy == false){
       //  monies -= 300;
        // }
        //  tribuy = true;
     }
     
      if (e.getKeyCode() == KeyEvent.VK_X){
          //&& shop && gamewon && monies >= 400) || 
          ship.weapon = "rocket";
        
       //  if(rockbuy == false){
        // monies -= 400;
        // }
         //rockbuy = true;
     }
      
       if (e.getKeyCode() == KeyEvent.VK_C  
            ){
          // && shop && gamewon && monies >= 200
         ship.weapon = "minigun";
        
      //   if(minibuy == false){
      //   monies -= 200;
      //   }
      //   minibuy = true;
     }
       if(e.getKeyCode() == KeyEvent.VK_I && shop && gamewon && monies >= 500 && ship.Body == "default" && armor1buy == false){
           monies -= 500;
           ship.Body = "armored";
           armor1buy = true;
       }
       else if (e.getKeyCode() == KeyEvent.VK_I && shop && gamewon && monies >= 600 && ship.Body == "armored" && armor2buy == false && armor1buy){
           monies -= 600;
           ship.Body = "iron";
           armor2buy = true;
       }
        else if (e.getKeyCode() == KeyEvent.VK_I && shop && gamewon && monies >= 700 && ship.Body == "iron" && armor3buy == false && armor2buy){
           monies -= 700;
           ship.Body = "steel";
           armor3buy = true;
       }
        else if ((e.getKeyCode() == KeyEvent.VK_I && shop && gamewon && monies >= 800 && ship.Body == "steel" || e.getKeyCode() == KeyEvent.VK_I && shop && gamewon && monies >= 800 && ship.Body == "gold" ||e.getKeyCode() == KeyEvent.VK_I && shop && gamewon && monies >= 800 && ship.Body == "ruby" )|| armor4buy){
    ship.Body = "reinforced"; 
            if (armor4buy == false){
                //e.getKeyCode() == KeyEvent.VK_I && shop && gamewon && monies >= 800 && ship.Body == "diamond" 
        monies -= 800;
    }
  
    armor4buy = true;
}
        else if (e.getKeyCode() == KeyEvent.VK_O && shop && gamewon && monies >= 1000 && ship.Body == "steel" || e.getKeyCode() == KeyEvent.VK_O && shop && gamewon && monies >= 1000 && ship.Body == "reinforced" ){
            if (gold == false){
                monies -= 1000;
            }
            ship.Body = "gold";
            gold = true;
        }
       
         else if (e.getKeyCode() == KeyEvent.VK_O && shop && gamewon && monies >= 2000 && ship.Body == "gold" && gold ){
            if (ruby == false){
                monies -= 2000;
            }
            ship.Body = "ruby";
            ruby = true;
        }
       
          else if ((e.getKeyCode() == KeyEvent.VK_O && shop && gamewon && monies >= 10000 && ship.Body == "ruby" && ruby) || diamond ){
           ship.Body = "diamond";
              if (diamond == false){
                monies -= 10000;
            }
           
            diamond = true;
        }
        if (e.getKeyCode() == KeyEvent.VK_P && shop && gamewon && monies >= 4000){
              monies -= 4000;
              livesbuy ++;
              ship.livesbought = livesbuy;
          }
       
          if (e.getKeyCode() == KeyEvent.VK_M && shop && gamewon && monies >= 3000 && magnetbuy == false){
              monies -= 3000;
              magnetbuy = true;
          }
          
          if(e.getKeyCode() == KeyEvent.VK_B && shop && gamewon && monies >= 400 && rockbuy == false){
              monies -= 400;
                      rockbuy = true;
          }
                if(e.getKeyCode() == KeyEvent.VK_T && shop && gamewon && monies >= 600 && tribuy == false){
              monies -= 600;
                      tribuy = true;
          }
                
                 if(e.getKeyCode() == KeyEvent.VK_U && shop && gamewon && monies >= 100000 && minibuy == false){
              monies -= 100000;
                      minibuy = true;
          }
           
      if (e.getKeyCode() == KeyEvent.VK_Q){
          ship.weapon = "pistol";
      }
      
      if (e.getKeyCode() == KeyEvent.VK_L){
          shop = true;
          gamewon = true;
      }
      
      if (e.getKeyCode() == KeyEvent.VK_K){
          shop = false;
           gamewon = false; 
           shopreset();
      }
      
      
      
      if (e.getKeyCode() == KeyEvent.VK_1 && diamond){
          ship.Body = "diamond";
   diamond = true;
      }
      
      if(e.getKeyCode()== KeyEvent.VK_2 && armor4buy){
         
          ship.Body = "reinforced";
      }
           
    //  if(e.getKeyCode() == KeyEvent.VK_3){
    //  monies += 4000;
   //   }
      
      if((e.getKeyCode() == KeyEvent.VK_4 && manbuy == false && monies >= 69) || manbuy){
          ship.Body = "pink";
          if (manbuy == false){
              monies -= 69;
          }
          manbuy = true;
                
      }
      
      if (e.getKeyCode() == KeyEvent.VK_SEMICOLON){
          cheat = reader.next().toString().replaceAll("\n","");
          if (cheat.equals("isaac")){
              ship.lives += 100;
              monies += 100000;
              ship.Body = "diamond";
              score += 100000;
          }
      }
      
     // if((e.getKeyCode() == KeyEvent.VK_5 && manbuy && supermanbuy == false && monies >= 6969 && ship.Body == "pink") || supermanbuy && ship.Body == "pink"){
         
      //    if (supermanbuy == false){
         //    monies -=6969; 
        //  }
       //   supermanbuy = true;
         //         if (MANUP){
           //           MANUP = false;
            //      }
          //        else{
             //         MANUP = true;
             //     }
     // }
     
             //make s key slow down and stop ship
     
     //make invincbiliy cheat key or sheild 
    
}
public void keycheck(){
   if (upkey){
       ship.accelerate();
   }
   
   if (leftkey) {
       ship.accelerate();
       ship.rotateleft();
   }
    if(rightkey){
        ship.accelerate();
       ship.rotateright();
    }
   if(spacekey){
    fireweapon();
   }
   if (downkey){
       ship.deccelerate();
   }
}
public void keyTyped(KeyEvent e){
    
    
}

public void keyReleased(KeyEvent e){
//  
if (e.getKeyCode() == KeyEvent.VK_D){ 
   // ship.xspeed = 0;
    
rightkey = false;
}
 if (e.getKeyCode() == KeyEvent.VK_A) {
//    ship.xspeed = 0;
//    
leftkey = false;
 }
if (e.getKeyCode() == KeyEvent.VK_W) {
//      ship.yspeed = 0;
upkey = false;
thruster.stop();
}
if (e.getKeyCode() == KeyEvent.VK_S) {
      downkey = false;
      thruster.stop();
  }


if(e.getKeyCode() == KeyEvent.VK_SPACE){
    spacekey = false;
}
}

public void actionPerformed(ActionEvent e){
    keycheck();
    respawn();
  //  System.out.println(cheat);
    ship.updatePostion();
    for (int i = 0; i < asteriodlist.size(); i++) {
         asteriodlist.get(i).updatePostion();
        if (asteriodlist.get(i).active == false){
           score += 1000* asteriodlist.get(i).size;
           asteriodhit.play();
           rockbreak();
        }
       
    }
    for (int i = 0; i < bulletlist.size(); i++) {
        
         bulletlist.get(i).updatePostion();
        if (bulletlist.get(i).stopwatch > 50 || bulletlist.get(i).active == false){
        bulletlist.remove(i);
        }
       
    }
    for (int i = 0; i < debrislist.size(); i++) {
        debrislist.get(i).updatePostion();
        if(debrislist.get(i).stopwatch == 50 && tribuy == false){
            debrislist.remove(i);
        }
        else if (tribuy && debrislist.get(i).stopwatch == 150){
             debrislist.remove(i);
        }
        
    }
    for (int i = 0; i < rocketlist.size(); i++) {
        rocketlist.get(i).updatePostion();
         if (rocketlist.get(i).stopwatch > 50 || rocketlist.get(i).active == false){
        rocketlist.remove(i);
        }
    }
     checkcollision();
    for (int i = 0; i < debrislist.size(); i++) {
        
    
    
    }
     checkhits();
      for (int i = 0; i < debrislist.size(); i++) {
     if(debrismagnet(debrislist.get(i)) && magnetbuy){
          double x,y,h;
  
        x = ship.xpostion - debrislist.get(i).xpostion;
        y =ship.ypostion - debrislist.get(i).ypostion ;
      
        h = Math.sqrt(x*x + y*y);
      debrislist.get(i).yspeed = Integer.signum((int)y)*20*Math.sin(Math.asin(Math.abs(y)/h));
      debrislist.get(i).xspeed = Integer.signum((int)x)*20*Math.cos(Math.acos(Math.abs(x)/h));
         }
     }
     
}

public boolean collision(Vectorsprite v1,Vectorsprite v2){
        int x,y;
    for (int i = 0; i < v1.drawshape.npoints; i++) {
    x =v1.drawshape.xpoints[i];
    y =v1.drawshape.ypoints[i];
    if(v2.drawshape.contains(x,y)){
        return true;
    }
        
    }
    
    for (int i = 0; i < v2.drawshape.npoints; i++) {
 x =v2.drawshape.xpoints[i];
    y =v2.drawshape.ypoints[i];
    if(v1.drawshape.contains(x,y)){
        return true;
    }
    }
    
    
    
    return false;
    
}

public void checkcollision(){
     for (int i = 0; i < asteriodlist.size(); i++) {
        
     for (int j = 0; j < bulletlist.size(); j++) {
        if (collision(asteriodlist.get(i),bulletlist.get(j))){
            asteriodlist.get(i).active = false;
                    bulletlist.get(j).active = false;
               if (ship.weapon != "minigun"){
                  if(rockbuy != true){
                   for (int k = 0; k < 10*asteriodlist.get(i).size; k++) {
                
            
                debrislist.add(new Debris (asteriodlist.get(i).xpostion,asteriodlist.get(i).ypostion));
                  }
                  }
                  else{
                   for (int k = 0; k < 20*asteriodlist.get(i).size; k++) {
                        debrislist.add(new Debris (asteriodlist.get(i).xpostion,asteriodlist.get(i).ypostion)); 
                   }
                  }
               }
               else{
                   for (int k = 0; k < 5*asteriodlist.get(i).size; k++) {
                   debrislist.add(new Debris (asteriodlist.get(i).xpostion,asteriodlist.get(i).ypostion));
               }
               }
        }
    }


     if (collision(asteriodlist.get(i),ship) && ship.active){
         for (int j = 0; j < 10; j++) {
              debrislist.add(new Debris (ship.xpostion,ship.ypostion));
         
         ship.xspeed = 0;
         asteriodlist.get(i).xspeed = -asteriodlist.get(i).xspeed;
         ship.yspeed = 0;
         asteriodlist.get(i).yspeed = -asteriodlist.get(i).yspeed;
        asteriodlist.get(i).angle = -asteriodlist.get(i).angle;
                 }
                 shiphit.play();
         ship.crash();
        
     }
     }
    for (int i = 0; i < debrislist.size(); i++) {
        if (collision(ship,debrislist.get(i)) && ship.active && debrislist.get(i).active){
            
            debrislist.get(i).active = false;
           debrislist.remove(i);
           if (ship.Body != "gold" && ship.Body != "ruby" && ship.Body != "dimaond"){
           monies += 10;
           }
           else if (ship.Body == "gold"){
               monies += 20;
           }
           else if (ship.Body == "ruby"){
               monies += 30;
           }
           else if (ship.Body == "diamond"){
               monies += 40;
           }
        }
        
    }
      for (int i = 0; i < asteriodlist.size(); i++) {
        
     for (int j = 0; j < rocketlist.size(); j++) {
        if (collision(asteriodlist.get(i),rocketlist.get(j))){
            asteriodlist.get(i).active = false;
                    rocketlist.get(j).active = false;
                  for (int k = 0; k < 50*asteriodlist.get(i).size; k++) {
                
            
                debrislist.add(new Debris (asteriodlist.get(i).xpostion,asteriodlist.get(i).ypostion));
                  }
        }
    }
   

}
}
        public void respawn(){
           if (ship.active == false && respawnsafe() == true){
               ship.reset();
           }
        }
        

public boolean respawnsafe(){
        double x,y,h;
    for (int i = 0; i < asteriodlist.size(); i++) {
        x = asteriodlist.get(i).xpostion - 450;
        y = asteriodlist.get(i).ypostion - 300;
        h = Math.sqrt(x*x + y*y);
        if( h < 100 ){
            return false;
        }
                
    }
        return true;
    }

public void fireweapon(){
    if (ship.active && ship.stopwatch > 30 && ship.weapon == "rocket"){
        rocketlist.add(new Rocket(ship.drawshape.xpoints[0],ship.drawshape.ypoints[0],ship.angle));
         ship.stopwatch = 0;
    }
    if(ship.active == true && ship.stopwatch > 2 && ship.weapon == "minigun"){
        bulletlist.add(new Weapon(ship.drawshape.xpoints[0],ship.drawshape.ypoints[0],ship.angle));
           ship.stopwatch = 0;
    }
   if(ship.active == true && ship.stopwatch > 5){
       if(ship.weapon == "pistol" ){
       bulletlist.add(new Weapon(ship.drawshape.xpoints[0],ship.drawshape.ypoints[0],ship.angle));
     
       }
       else if(ship.weapon == "trishot"){
            bulletlist.add(new Weapon(ship.drawshape.xpoints[0],ship.drawshape.ypoints[0],ship.angle));
             bulletlist.add(new Weapon(ship.drawshape.xpoints[0],ship.drawshape.ypoints[0],ship.angle - 1));
              bulletlist.add(new Weapon(ship.drawshape.xpoints[0],ship.drawshape.ypoints[0],ship.angle + 1 ));
             
       }
        laser.play();
       ship.stopwatch = 0;
   }
}
        

public void rockbreak(){
    for (int i = 0; i < asteriodlist.size(); i++) {
        if (asteriodlist.get(i).active == false && ship.weapon == "pistol" ||asteriodlist.get(i).active == false && ship.weapon == "trishot"||asteriodlist.get(i).active == false && ship.weapon == "minigun" ){
            if(asteriodlist.get(i).size > 1){
            asteriodlist.add(new Asteriods(asteriodlist.get(i).xpostion,asteriodlist.get(i).ypostion,asteriodlist.get(i).size - 1));
             asteriodlist.add(new Asteriods(asteriodlist.get(i).xpostion,asteriodlist.get(i).ypostion,asteriodlist.get(i).size - 1));
            }
             asteriodlist.remove(i);
        }
        else if (asteriodlist.get(i).active == false && ship.weapon == "rocket" ){
            if(asteriodlist.get(i).size > 1){
            asteriodlist.add(new Asteriods(asteriodlist.get(i).xpostion,asteriodlist.get(i).ypostion,asteriodlist.get(i).size - 2));
             asteriodlist.add(new Asteriods(asteriodlist.get(i).xpostion,asteriodlist.get(i).ypostion,asteriodlist.get(i).size - 2));
              asteriodlist.add(new Asteriods(asteriodlist.get(i).xpostion,asteriodlist.get(i).ypostion,asteriodlist.get(i).size - 2));
             asteriodlist.add(new Asteriods(asteriodlist.get(i).xpostion,asteriodlist.get(i).ypostion,asteriodlist.get(i).size - 2));
              asteriodlist.add(new Asteriods(asteriodlist.get(i).xpostion,asteriodlist.get(i).ypostion,asteriodlist.get(i).size - 2));
             asteriodlist.add(new Asteriods(asteriodlist.get(i).xpostion,asteriodlist.get(i).ypostion,asteriodlist.get(i).size - 2));
              asteriodlist.add(new Asteriods(asteriodlist.get(i).xpostion,asteriodlist.get(i).ypostion,asteriodlist.get(i).size - 2));
             asteriodlist.add(new Asteriods(asteriodlist.get(i).xpostion,asteriodlist.get(i).ypostion,asteriodlist.get(i).size - 2));
              asteriodlist.add(new Asteriods(asteriodlist.get(i).xpostion,asteriodlist.get(i).ypostion,asteriodlist.get(i).size - 2));
             asteriodlist.add(new Asteriods(asteriodlist.get(i).xpostion,asteriodlist.get(i).ypostion,asteriodlist.get(i).size - 2));
              }
            asteriodlist.remove(i);
        }
                
    }
}
// make different wepapons tunr asteriods into different pieces

public void shopreset(){
        gamewon = true;
    if (asteriodlist.isEmpty() == true){
    for (int i = 0; i < 6; i++) {
            
        
    asteriodlist.add(new Asteriods());
        }
       }
    else if (asteriodlist.size() > 6){
           asteriodlist.removeAll(asteriodlist);
           for (int i = 0; i < 6; i++) {
            
        
    asteriodlist.add(new Asteriods());
        }
           ship.lives = 5;
           
       }
      
}


public void checkhits(){
    for (int i = 0; i < asteriodlist.size(); i++) {
        
    
    if (collision(ship,asteriodlist.get(i))){
        ship.hits -= 1;
        ship.crash();
    }
            }
}

public boolean debrismagnet(Debris d){
         double x,y,h;
  
        x = Math.abs((d).xpostion - ship.xpostion);
        y =Math.abs(d.ypostion - ship.ypostion);
        h = Math.sqrt(x*x + y*y);
        if( h < 50 ){
            return true;
        }
                
    
        return false;
        
        
        
    }



































}
