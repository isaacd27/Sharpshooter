
import java.awt.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RealProgramming4Kids
 */
public class Asteriods extends Vectorsprite {
    double a,h;
    int size;
   public Asteriods(){
         size = 3;
       initasteriod();
      
   }
   public Asteriods(double x,double y,int s){
     size = s;
       initasteriod();
       xpostion = x;
       ypostion = y;
   }
   
   
    public void initasteriod(){
          shape = new Polygon();
         shape.addPoint(10*size,1*size);
         shape.addPoint(2*size,15*size);
         shape.addPoint(-10*size,4*size);
         shape.addPoint(-10*size,-6*size);
         shape.addPoint(6*size,-12*size);
         active = true;
          drawshape = new Polygon();
         drawshape.addPoint(30*size,3*size);
         drawshape.addPoint(5*size,35*size);
         drawshape.addPoint(-25*size,10*size);
         drawshape.addPoint(-17*size,-15*size);
         drawshape.addPoint(20*size,-35*size);
       
         ROTATION = 0.15;
    h = Math.random() + 1;
       a = Math.random()* Math.PI*2;
       xspeed = Math.cos(a)*h;
       yspeed = Math.sin(a)*h;
       
       h= Math.random()*400 +100;
       a= Math.random()*Math.PI*2;
       
       xpostion = Math.cos(a)*h + 450;
       ypostion = Math.sin(a)*h + 300;
       
   }
    
    //make asteroids explode into coins, use coins to buy weapons
    
    
    
      public void accelerate(){
    xpostion += xspeed;
    ypostion += yspeed;
          
          yspeed += ROCKETS*Math.sin(angle - Math.PI/2);
    xspeed += ROCKETS*Math.cos(angle - Math.PI/2);
}
    
    
    
         public void updatePostion(){
super.updatePostion();
angle += ROTATION;
         }
    
    
    
    
    
    
    
    
    
    
    
}
