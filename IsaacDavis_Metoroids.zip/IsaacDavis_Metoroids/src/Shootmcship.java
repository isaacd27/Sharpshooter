
import java.awt.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author R isaac d
 */
public class Shootmcship extends Vectorsprite {
    int lives = 5;
    String weapon;
    String Body;
    int hits;
    int livesbought;
    boolean livesset1,livesset2,livesset3;
    boolean livesset4,manset;
    public Shootmcship(){
          shape = new Polygon();
         shape.addPoint(0,-25);
         shape.addPoint(-15,10);
         shape.addPoint(15,10);
         weapon = "pistol";
         Body = "default";
         drawshape = new Polygon();
         drawshape.addPoint(0,-25);
         drawshape.addPoint(-15,10);
         drawshape.addPoint(15,10);
         xpostion = 450;
         ypostion = 300;
         ROTATION = 0.2;
     ROCKETS = 5;
     active = true;
    }
    public void accelerate(){
    yspeed = ROCKETS*Math.sin(angle - Math.PI/2);
    xspeed = ROCKETS*Math.cos(angle - Math.PI/2);
}
    public void deccelerate(){
     if (xspeed != 0 && yspeed != 0 || xspeed > 10 && yspeed > 10 || xspeed < -10 && yspeed > 10  || xspeed > 10 && yspeed < -10 || xspeed < -10 && yspeed < -10){
     yspeed = 0;
    xspeed = 0;
     }
    }
    // take out + for no acclerate
    
    
    
    
    
    public void rotateleft(){
        angle -= ROTATION;
    }
    public void rotateright(){
         angle += ROTATION;
    }
    
    
    public void crash(){
    if (active && hits <= 1){
        lives -= 1;
        active = false;
    }
    else if (hits > 1 && active){
        hits -= 1;
    }
        
    stopwatch = 0;
    if (Body == "default"){
        hits = 1;
   
    }
    
     if(Body == "armored" && active == false && livesset1 == false){
        hits = 3;
        lives = 8;
        livesset1 = true;
    }
      if(Body == "iron" && active == false && livesset2 == false){
        hits = 4;
        lives = 9;
        livesset2 = true;
    }
      
      if(Body == "steel" && active == false && livesset3 == false){
          lives = 10;
                  livesset3 =true;
      }
         
      
         if(Body == "reinforced"  && active == false && livesset4 == false){
          lives = 15;
                  livesset4 =true;
         }
      if(Body == "pink"){
          lives = 1;
          manset = true;
      }
         
         if(Body =="gold" || Body == "ruby" || Body == "diamond"){
             livesset4 = false;
             manset = false;
         }
    if( lives == 0){
        livesset1 = false;
        livesset2 = false;
        livesset3 = false;
        livesset4 = false;
        manset = false;
    }
    
    if (livesbought > 0){
       if (Body == "default" || Body == "gold" || Body == "ruby" || Body == "diamond"){
        lives = 5 + livesbought;
       }
       if(Body == "armored"){
        
        lives = 8 + livesbought;
       
    }
      if(Body == "iron"){
      
        lives = 9 + livesbought;
        
    }
      
      if(Body == "steel"){
          lives = 10 + livesbought;
                  
      }
         
      
         if(Body == "reinforced"){
          lives = 15 + livesbought;
                
      }
         if (Body == "pink"){
             lives = 1 + livesbought;
         }
        livesbought = 0;
    }
}
    
    
    public void reset(){
         xpostion = 450;
         ypostion = 300;
         xspeed = 0;
                 yspeed = 0;
                         angle = 0;
                         active = true;
    }

}
