
import java.awt.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RealProgramming4Kids
 */
public class Weapon extends Vectorsprite{
   
    public Weapon(double x, double y, double a){
    shape = new Polygon();
    shape.addPoint(0,0);
         shape.addPoint(0,0);
         shape.addPoint(0,0);
         shape.addPoint(0,0);
     
       
          drawshape = new Polygon();
         drawshape.addPoint(0,0);
         drawshape.addPoint(0,0);
         drawshape.addPoint(0,0);
         drawshape.addPoint(0,0);
         active = true;
         xpostion = x;
         ypostion = y;
         angle = a;
         ROCKETS = 10;
       yspeed = ROCKETS*Math.sin(angle - Math.PI/2);
    xspeed = ROCKETS*Math.cos(angle - Math.PI/2);
        }
    
    
    
    
    
    
    
}
