
import java.awt.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author isaacdavis
 */
public class Vectorsprite {
    double xpostion;
     double ypostion;
     double xspeed;
     double yspeed;
     double angle;
     Polygon shape;
     Polygon drawshape;
     double ROTATION;
  double ROCKETS;
  boolean active;
  int stopwatch;
     public Vectorsprite(){
      
     }
     
     public void paint(Graphics g) {
         g.drawPolygon(drawshape);
         
     }
     
     public void updatePostion(){
        int x,y;
        stopwatch += 1;
         xpostion += xspeed;
         ypostion += yspeed;
         
         for(int i = 0; i< shape.npoints; i++) {
            //shape.xpoints[i] += xspeed;
           //shape.ypoints[i] += yspeed;
             x = (int)Math.round(shape.xpoints[i]*Math.cos(angle) - shape.ypoints[i]*Math.sin(angle));
             y = (int)Math.round( shape.xpoints[i]*Math.sin(angle) + shape.ypoints[i]*Math.cos(angle));
             drawshape.xpoints[i] = x;
             drawshape.ypoints[i] = y;
             
         
         
         }
         drawshape.invalidate();
         drawshape.translate ((int)Math.round(xpostion),(int)Math.round (ypostion));
         loop();
     }
     private void loop(){
    if (xpostion < 0) {
        xpostion = 900;
    }
    
    if (xpostion > 900) {
        xpostion = 0;
    }
    
    
     if (ypostion < 0) {
        ypostion = 600;
    }
    
    if (ypostion > 600) {
        ypostion = 0;
    }
    
    
    
     }
     
     
     
     
}
