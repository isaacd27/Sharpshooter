/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.*;
/**
 *
 * @author Isaac D
 */
public class Debris extends Vectorsprite{
    public Debris(double x, double y){
   
           shape = new Polygon();
           shape.addPoint(1,1);
           shape.addPoint(-1,-1);
              shape.addPoint(-1,-1);
                shape.addPoint(-1,-1);
                
                drawshape = new Polygon();
                  drawshape.addPoint(1,1);
                    drawshape.addPoint(-1,-1);
                    drawshape.addPoint(-1,-1);
                    drawshape.addPoint(-1,-1);
                   
                    xpostion = x;
                    ypostion = y;
                      double a;
     a = Math.random()*2*Math.PI;
     active = true;
                     yspeed = Math.sin(a)*a;
    xspeed = Math.cos(a)*a;
                    ROTATION = 0.2;
    // ROCKETS = 10;
   
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
}  
   
}
