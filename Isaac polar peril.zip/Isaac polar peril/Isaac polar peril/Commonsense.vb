﻿Module Commonsense
    Public quit As Boolean
    Public Namepic As String
    Public easymode As Boolean
    Structure Sprite
        Dim Speed As Point
        Dim Jumptime As Integer
        Dim Picknum As Integer
        Dim Facer As Boolean
        Dim jumping As Boolean
        Dim Climbing As Boolean
        Dim Elevate As Integer
        Dim onfloor As Boolean
    End Structure
    Structure Floortype
        Dim X As Single
        Dim Y As Single
        Dim Slope As Single
        Dim leftedge As Integer
        Dim Rightedge As Integer
    End Structure
End Module
