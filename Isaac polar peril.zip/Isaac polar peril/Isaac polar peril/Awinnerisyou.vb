﻿Public Class Awinnerisyou



    Private Sub Yesbutt_Click(sender As Object, e As EventArgs) Handles Yesbutt.Click
        easymode = False
        Me.Close()
    End Sub

    Private Sub Nope_Click(sender As Object, e As EventArgs) Handles Nope.Click
        quit = True
        Me.Close()
    End Sub
End Class