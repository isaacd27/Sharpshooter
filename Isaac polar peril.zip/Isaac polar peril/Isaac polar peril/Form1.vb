﻿Public Class Form1
    Dim HikerSprite As Sprite
    Dim Ladder(NUMLADDER) As PictureBox
    Const NUMLADDER As Integer = 7
    Dim Icefloor(NUMFLOOR) As Floortype
    Const NUMFLOOR As Integer = 6
    Dim Snowball(3) As PictureBox
    Dim BALLNUM As Integer
    Dim Snowsprite(3) As Sprite
    Dim Random As Integer
    Dim Throwtimer As Integer
    Const BALLTICK As Integer = 42
    Dim Dancing As Boolean
    Dim pressKey As Integer
    Dim krtimer As Integer = 0
    Dim krrtimer As Integer = 0
    Dim Helptimer As Integer
    Dim ikey As Boolean
    Dim skey As Boolean
    Dim akey As Boolean
    Dim ckey As Boolean
    Dim spacekey As Boolean
    Dim Lives(3) As PictureBox
    Dim Livesleft As Integer
    Dim Firetime As Integer
    Dim FlameSprite As Sprite
    Dim Hkey As Boolean
    Dim beekey As Boolean
    Dim bombtimer As Integer
    Dim Bombsprite As Sprite
    Dim bombuse As Boolean = False
    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown

        If e.KeyCode = Keys.Left Then
            pressKey = 1
            HikerSprite.Facer = False

            If Hiker.Left > 77 Then
                HikerSprite.Speed.X = -10
            Else
                HikerSprite.Speed.X = 0
            End If

        End If
        If e.KeyCode = Keys.Right Then
            pressKey = 2
            HikerSprite.Facer = True

            If Hiker.Left < 540 Then
                HikerSprite.Speed.X = 10
            Else
                HikerSprite.Speed.X = 0

            End If
        End If
        If e.KeyCode = Keys.Up And HikerSprite.jumping = False Then
            HikerSprite.Speed.Y = -3

        End If
        If e.KeyCode = Keys.Down And HikerSprite.jumping = False Then
            HikerSprite.Speed.Y = 3
        End If

        If e.KeyCode = Keys.Space And HikerSprite.Speed.Y = 0 Then
            HikerSprite.Jumptime = 0
            HikerSprite.Speed.Y = -5
            HikerSprite.jumping = True
            HikerSprite.onfloor = False
            For index = 0 To BALLNUM
                If SnowSoundeffect(index) = True Then
                    My.Computer.Audio.Play(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\Sounds\jumpbar.wav", AudioPlayMode.Background)

                Else
                    My.Computer.Audio.Play(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\Sounds\jump.wav", AudioPlayMode.Background)

                End If
            Next
        End If

        If e.KeyCode = Keys.Z Then
            HikerSprite.Speed.X = 0
            pressKey = 0
        End If
        If e.KeyCode = Keys.H Then
            Hkey = True
            If HikerSprite.Facer = True Then
                HikerSprite.Speed.X = -10
            Else
                HikerSprite.Speed.X = 10
            End If
        End If
        If e.KeyCode = Keys.B Then
            beekey = True
        End If
    End Sub

    Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles Me.KeyUp
        If e.KeyCode = Keys.Left Then
            pressKey = 3
        End If

        If e.KeyCode = Keys.Right Then
            pressKey = 4
        End If
        If e.KeyCode = Keys.Up Or e.KeyCode = Keys.Down Then
            If HikerSprite.jumping = False Then

                HikerSprite.Speed.Y = 0
            End If
        End If
        If e.KeyCode = Keys.I Then
            ikey = True
        End If
        If e.KeyCode = Keys.S And ikey = True Then
            skey = True
        End If
        If e.KeyCode = Keys.A And skey = True Then
            akey = True
        End If
        If e.KeyCode = Keys.C And akey = True Then
            ckey = True
        End If
        If e.KeyCode = Keys.H Then
            Hkey = False
        End If
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        mainMenu.ShowDialog()
        beekey = False
        If easymode = False Then
            BALLNUM = 3
        Else
            BALLNUM = 1
        End If
        Namepic = "\pics\nansendead.jpg"
        Livesleft = 3
        pressKey = 0
        Lives(0) = life0
        Lives(1) = life1
        Lives(2) = life2
        Lives(3) = life3

        Call Tryagainyes()
        quit = False
        Timer27.Start()
    End Sub
    Private Sub Timer27_Tick(sender As Object, e As EventArgs) Handles Timer27.Tick
        If quit = True Then
            Me.Close()
        End If

        If pressKey = 3 Then
            Call slowleft()
        End If

        If pressKey = 4 Then
            Call slowright()
        End If

        Call MoveHiker()
        Call AnimateHiker()
        For index = 0 To BALLNUM
            If Snowball(index).Visible = True Then
                Call BallRoll(index)
                Call Animateball(index)
                If hit(Hiker, Snowball(index)) = True Then
                    Namepic = "\pics\nansendead.jpg"
                    My.Computer.Audio.Play(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\Sounds\Death.wav", AudioPlayMode.Background)
                    Call crushhiker()

                End If
            End If
        Next
        Call Throwball()
        Call Animateyeti()
        If hit(Hiker, Yeti) = True Then
            Namepic = "\pics\nansenSpin.jpg"
            My.Computer.Audio.Play(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\Sounds\Death.wav", AudioPlayMode.Background)
            Call crushhiker()
        End If
        Call Helpme()
        If hit(Hiker, Damsel) = True Then
            Timer27.Stop()
            Awinnerisyou.ShowDialog()
            Livesleft = 3
            For index = 0 To 3
                Lives(index).Visible = True
            Next
            Call Tryagainyes()
            Timer27.Start()
        End If
        If ckey = True Then
            Hiker.Left = 243
            Hiker.Top = 10
            ckey = False
            akey = False
            skey = False
            ikey = False
            My.Computer.Audio.Play(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\Sounds\jumpbar.wav", AudioPlayMode.Background)
        End If
        Call fire()
        Call KABOOM()


    End Sub
    Private Sub slowleft()
        krtimer = krtimer + 1
        If krtimer > 2 Then
            If HikerSprite.Speed.X <> 0 Then
                HikerSprite.Speed.X = HikerSprite.Speed.X + 2
            End If
            krtimer = 0
        End If
    End Sub
    Private Sub slowright()
        krrtimer = krrtimer + 1
        If krrtimer > 2 Then
            If HikerSprite.Speed.X <> 0 Then
                HikerSprite.Speed.X = HikerSprite.Speed.X - 2
            End If
            krrtimer = 0
        End If
    End Sub
    Private Sub MoveHiker()
        HikerSprite.Elevate = FloorNumber(Hiker.Top)
        If HikerSprite.jumping = True Then
            Call jump(HikerSprite)
        Else
            HikerSprite.Climbing = Checkladder()

            If HikerSprite.Climbing = False Then
                Call Skate(HikerSprite, Hiker)

            Else

                HikerSprite.Speed.X = 0

            End If
        End If

        If (Hiker.Left < 77 And HikerSprite.Speed.X < 0) Or (Hiker.Left > 540 And HikerSprite.Speed.X > 0) Then
            HikerSprite.Speed.X = 0
        End If

        Hiker.Left = Hiker.Left + HikerSprite.Speed.X
        Hiker.Top = Hiker.Top + HikerSprite.Speed.Y
    End Sub
    Private Sub AnimateHiker()
        If HikerSprite.Speed.Y <> 0 Then
            If HikerSprite.jumping = True Then
                Call AnimateHikerjump()
            Else
                Call AnimateRope()
            End If
        Else
            If HikerSprite.Speed.X > 0 And HikerSprite.Facer = True Then
                Call AnimateHikerright()
            ElseIf HikerSprite.Speed.X < 0 And HikerSprite.Facer = False Then
                Call AnimateHikerleft()
            Else
                Call Animateidlehik()
            End If
        End If


    End Sub
    Private Sub AnimateHikerright()
        If HikerSprite.Speed.X > 8 Then

            If HikerSprite.Picknum = 1 Then
                Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenrightmove1.jpg")
                HikerSprite.Picknum = 2
            ElseIf HikerSprite.Picknum = 2 Then
                Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenrightmove2.jpg")
                HikerSprite.Picknum = 3
            ElseIf HikerSprite.Picknum = 3 Then
                Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenrightmove3.jpg")
                HikerSprite.Picknum = 1
            End If

        Else
            Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenrightmove1.jpg")
        End If


    End Sub
    Private Sub AnimateHikerleft()
        If HikerSprite.Speed.X < -8 Then
            If HikerSprite.Picknum = 1 Then
                Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenleftmove1.jpg")
                HikerSprite.Picknum = 2
            ElseIf HikerSprite.Picknum = 2 Then
                Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenleftmove2.jpg")
                HikerSprite.Picknum = 3
            ElseIf HikerSprite.Picknum = 3 Then
                Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenleftmove3.jpg")
                HikerSprite.Picknum = 1
            End If
        Else
            Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenleftmove1.jpg")
        End If
    End Sub
    Private Sub AnimateHikerjump()
        If HikerSprite.Speed.X > 0 And HikerSprite.Facer = True Then
            Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenrightfloat.jpg")
        ElseIf HikerSprite.Speed.X < 0 And HikerSprite.Facer = False Then
            Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenleftfloat.jpg")
        ElseIf HikerSprite.Speed.X = 0 Then
            If HikerSprite.Facer = True Then
                Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenrightfloat.jpg")
            Else
                Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenleftfloat.jpg")
            End If
        End If
    End Sub
    Private Sub Animateidlehik()
        If HikerSprite.Facer = True Then
            Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenrightmove1.jpg")
        Else
            Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenleftmove1.jpg")
        End If
    End Sub
    Private Sub Ladderlist()
        Ladder(0) = Ladder0
        Ladder(1) = Ladder1
        Ladder(2) = Ladder2
        Ladder(3) = Ladder3
        Ladder(4) = Ladder4
        Ladder(5) = Ladder5
        Ladder(6) = Ladder6 'shsadh
        Ladder(7) = ladder7
    End Sub
    Private Sub AnimateRope()
        If HikerSprite.Picknum = 1 Then
            Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenclimb1.jpg")
            HikerSprite.Picknum = 2
        ElseIf HikerSprite.Picknum = 2 Then
            Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenclimb2.jpg")
            HikerSprite.Picknum = 3
        ElseIf HikerSprite.Picknum = 3 Then
            Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenclimb3.jpg")
            HikerSprite.Picknum = 1
        End If

    End Sub
    Private Function Checkladder()
        Dim Ladderoffset As Integer
        Ladderoffset = 15

        For index = 0 To NUMLADDER
            If HikerSprite.Speed.Y = 0 Then
                If Hiker.Left > Ladder(index).Left - Ladderoffset And Hiker.Right < Ladder(index).Right + Ladderoffset Then
                    If Hiker.Bottom < Ladder(index).Bottom - 5 And Hiker.Bottom > Ladder(index).Top + 5 Then
                        Return True
                    End If
                End If
            ElseIf HikerSprite.Speed.Y < 0 Then
                If Hiker.Left > Ladder(index).Left - Ladderoffset And Hiker.Right < Ladder(index).Right + Ladderoffset Then
                    If Hiker.Top < Ladder(index).Bottom And Hiker.Bottom > Ladder(index).Top Then
                        Return True
                    End If
                End If
            ElseIf HikerSprite.Speed.Y > 0 Then
                If Hiker.Left > Ladder(index).Left - Ladderoffset And Hiker.Right < Ladder(index).Right + Ladderoffset Then
                    If Hiker.Bottom < Ladder(index).Bottom And Hiker.Bottom > Ladder(index).Top - Ladderoffset Then
                        Return True
                    End If
                End If
            End If
        Next
        Return False
    End Function
    Private Sub Climbfloor()
        Icefloor(0).Slope = -0.000001
        Icefloor(1).Slope = 0.078
        Icefloor(2).Slope = -0.078
        Icefloor(3).Slope = 0.078
        Icefloor(4).Slope = -0.078
        Icefloor(5).Slope = 0
        Icefloor(6).Slope = 0
        '---------------------'
        Icefloor(0).X = 137
        Icefloor(1).X = 137
        Icefloor(2).X = 137
        Icefloor(3).X = 137
        Icefloor(4).X = 137
        Icefloor(5).X = 137
        Icefloor(6).X = 137
        '------------------------'
        Icefloor(0).Y = 465
        Icefloor(1).Y = 377
        Icefloor(2).Y = 327
        Icefloor(3).Y = 226
        Icefloor(4).Y = 176
        Icefloor(5).Y = 92
        Icefloor(6).Y = 42
        '-------------------------
        Icefloor(0).leftedge = 0
        Icefloor(1).leftedge = 0
        Icefloor(2).leftedge = 133
        Icefloor(3).leftedge = 0
        Icefloor(4).leftedge = 133
        Icefloor(5).leftedge = 0
        Icefloor(6).leftedge = 200
        '------------------------------
        Icefloor(0).Rightedge = 570
        Icefloor(1).Rightedge = 507
        Icefloor(2).Rightedge = 570
        Icefloor(3).Rightedge = 507
        Icefloor(4).Rightedge = 570
        Icefloor(5).Rightedge = 507
        Icefloor(6).Rightedge = 312
    End Sub
    Private Function FloorNumber(ByVal thing As Integer)
        If thing < 20 Then
            Return 6
        ElseIf thing < 73 Then
            Return 5
        ElseIf thing < 160 Then
            Return 4
        ElseIf thing < 240 Then
            Return 3
        ElseIf thing < 320 Then
            Return 2
        ElseIf thing < 393 Then
            Return 1
        Else
            Return 0
        End If
    End Function
    Private Sub jump(ByRef Sprite1 As Sprite)
        If Sprite1.Jumptime = 5 Then
            If Sprite1.Speed.Y = -5 Then
                Sprite1.Speed.Y = 5
            Else
                Sprite1.Speed.Y = 0
                Sprite1.jumping = False
            End If
            Sprite1.Jumptime = 1
        Else
            Sprite1.Jumptime = Sprite1.Jumptime + 1
        End If
    End Sub
    Private Sub Skate(ByRef sprite1 As Sprite, ByRef Thing As PictureBox)
        sprite1.Speed.Y = 0
        sprite1.onfloor = True
        Thing.Top = Icefloor(sprite1.Elevate).Slope * (Thing.Left - Icefloor(sprite1.Elevate).X) + Icefloor(sprite1.Elevate).Y - Thing.Height
        If Thing.Right < Icefloor(sprite1.Elevate).leftedge Then
            sprite1.jumping = True
            sprite1.Jumptime = 1
            sprite1.Speed.Y = 5
        ElseIf Thing.Left > Icefloor(sprite1.Elevate).Rightedge Then
            sprite1.jumping = True
            sprite1.Jumptime = 1
            sprite1.Speed.Y = 5
        End If

    End Sub
    Private Sub BallSpawn()

        Snowball(0) = Snowball0
        Snowball(1) = Snowball1
        Snowball(2) = Snowball2
        Snowball(3) = Snowball3

        For index = 0 To 3
            Snowball(index).Visible = False
        Next

        For index = 0 To BALLNUM
            Snowsprite(index).jumping = False
            Snowsprite(index).Climbing = False
            Snowsprite(index).Picknum = 1
            Snowsprite(index).Speed.X = 10
            Snowsprite(index).Speed.Y = 0
            Snowball(index).Top = 70
            Snowball(index).Left = 200
        Next
    End Sub
    Private Sub BallRoll(ByVal index As Integer)
        Snowsprite(index).Elevate = FloorNumber(Snowball(index).Top)
        If Snowsprite(index).jumping = True Then
            Call jump(Snowsprite(index))
        Else
            Snowsprite(index).Climbing = Downroll(index)
            If Snowsprite(index).Climbing = False Then
                If Icefloor(Snowsprite(index).Elevate).Slope < 0 Then
                    Snowsprite(index).Speed.X = -10
                Else
                    Snowsprite(index).Speed.X = 10
                End If
                Call Skate(Snowsprite(index), Snowball(index))
            Else

                Snowsprite(index).Speed.X = 0
                Snowsprite(index).Speed.Y = 10
                Snowsprite(index).jumping = True

            End If
        End If

        If (Snowball(index).Left < 77 And Snowsprite(index).Speed.X < 0) Or (Snowball(index).Left > 540 And Snowsprite(index).Speed.X > 0) Then
            Snowsprite(index).Speed.X = 0
        End If
        Snowball(index).Left = Snowball(index).Left + Snowsprite(index).Speed.X
        Snowball(index).Top = Snowball(index).Top + Snowsprite(index).Speed.Y
        If Snowsprite(index).Elevate = 0 And Snowball(index).Left < 84 Then
            Snowball(index).Visible = False
            If Dancing = True Then
                Dancing = False
                Throwtimer = 0
                Yeti.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\bobstanding.jpg")
            End If
        End If
    End Sub
    Private Function Downroll(ByVal sindex As Integer)
        Dim Ladderoffset As Integer = 15
        Random = Int(Rnd() * 30)
        If Random Mod 5 = 0 Then

            For index = 0 To NUMLADDER
                If Snowball(sindex).Left > Ladder(index).Left And Snowball(sindex).Right < Ladder(index).Right Then
                    If Snowball(sindex).Bottom + Ladderoffset > Ladder(index).Top And Snowball(sindex).Bottom - Ladderoffset < Ladder(index).Top Then
                        Return True
                    End If
                End If
            Next
        End If

        Return False
    End Function
    Private Sub Animateball(ByVal index As Integer)

        If Snowsprite(index).Speed.X > 0 Then
            If Snowsprite(index).Picknum = 1 Then
                Snowball(index).Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "/pics/ball2.jpg")
                Snowsprite(index).Picknum = 2
            ElseIf Snowsprite(index).Picknum = 2 Then
                Snowball(index).Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "/pics/ball3.jpg")
                Snowsprite(index).Picknum = 3
            ElseIf Snowsprite(index).Picknum = 3 Then
                Snowball(index).Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "/pics/ball4.jpg")
                Snowsprite(index).Picknum = 4
            ElseIf Snowsprite(index).Picknum = 4 Then
                Snowball(index).Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "/pics/ball1.jpg")
                Snowsprite(index).Picknum = 1
            End If
        ElseIf Snowsprite(index).Speed.X < 0 Then
            If Snowsprite(index).Picknum = 1 Then
                Snowball(index).Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "/pics/ball1.jpg")
                Snowsprite(index).Picknum = 2
            ElseIf Snowsprite(index).Picknum = 2 Then
                Snowball(index).Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "/pics/ball4.jpg")
                Snowsprite(index).Picknum = 3
            ElseIf Snowsprite(index).Picknum = 3 Then
                Snowball(index).Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "/pics/ball3.jpg")
                Snowsprite(index).Picknum = 4
            ElseIf Snowsprite(index).Picknum = 4 Then
                Snowball(index).Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "/pics/ball2.jpg")
                Snowsprite(index).Picknum = 1
            End If
        End If
        
    End Sub
    Private Function hit(ByVal pic1 As PictureBox, ByVal pic2 As PictureBox)
        Dim Offset As Integer = 3
        If pic1.Left + Offset < pic2.Right And pic1.Right - Offset > pic2.Left Then
            If pic1.Bottom - 5 > pic2.Top And pic1.Top + 5 < pic2.Bottom Then
                Return True
            End If
        End If
        Return False
    End Function
    Private Sub Tryagainyes()
        Call Climbfloor()
        Call BallSpawn()
        Call Ladderlist()
        Call Playerspawn()
        Firetime = 0
        Flame.Left = 80
        Flame.Top = 405
        Flame.Visible = False
        Dancing = False
        beekey = False
        Bomb1.Visible = False
        bombuse = False
    End Sub
    Private Sub Playerspawn()
        HikerSprite.Picknum = 1
        HikerSprite.Facer = True
        Hiker.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\nansenrightmove1.jpg")
        Hiker.Left = 105
        Hiker.Top = 430
        HikerSprite.Speed.X = 0
        HikerSprite.Speed.Y = 0
        HikerSprite.onfloor = True

    End Sub
    Private Sub Throwball()
        Dim index As Integer
        Dim Finished As Boolean
        Dim index2 As Integer
        Throwtimer = Throwtimer + 1

        If Throwtimer = BALLTICK Then
            Throwtimer = 0
            Finished = False
            Do While Finished = False
                If Snowball(index).Visible = False Then
                    Finished = True
                    Snowball(index).Visible = True
                    Snowball(index).Top = 70
                    Snowball(index).Left = 200
                    Snowsprite(index).jumping = False
                    Snowsprite(index).Climbing = False
                    Snowsprite(index).Picknum = 1
                    Snowsprite(index).Speed.X = 10
                    Snowsprite(index).Speed.Y = 0
                    Dancing = True
                    For index2 = 0 To BALLNUM
                        If Snowball(index2).Visible = False Then
                            Dancing = False
                        End If
                    Next
                End If
                index = index + 1
                If index = (BALLNUM + 1) Then
                    Finished = True
                End If
            Loop
        End If
    End Sub
    Private Sub Animateyeti()
        If Dancing = False Then
            If Throwtimer > BALLTICK - 2 Then
                Yeti.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\bobrollingball.jpg")
            ElseIf Throwtimer > BALLTICK / 2 Then
                Yeti.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\bobholdingball.jpg")
            ElseIf Throwtimer > BALLTICK / 4 Then
                Yeti.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\bobgettingball.jpg")

            End If
        Else
            If Throwtimer > BALLTICK - 2 Then
                Yeti.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\bobsmiling.jpg")
            ElseIf Throwtimer > BALLTICK / 2 Then
                Yeti.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\bobdancing2.jpg")
            ElseIf Throwtimer > BALLTICK / 4 Then
                Yeti.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\bobdancing.jpg")
            ElseIf Throwtimer > BALLTICK / 8 Then
                Yeti.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\bobstanding.jpg")
            End If
        End If
    End Sub
    Private Sub Helpme()
        If Scream.Visible = False And Helptimer > 3 Then
            Scream.Visible = True
            Helptimer = 0
        ElseIf Scream.Visible = True And Helptimer > 3 Then

            Scream.Visible = False
            Helptimer = 0
        Else
            Helptimer = Helptimer + 1
        End If
    End Sub
    Private Sub crushhiker()
        If Livesleft > 0 Then
            Timer27.Stop()
            Lives(Livesleft).Visible = False
            Livesleft = Livesleft - 1
            Youaredead.ShowDialog()
            Call Tryagainyes()
            Timer27.Start()
        Else
            Timer27.Stop()
            Gameover.ShowDialog()
            Livesleft = 3
            For index = 0 To 3
                Lives(index).Visible = True
            Next
            Call Tryagainyes()
            Timer27.Start()

        End If
       
    End Sub
    Private Sub fire()
        Firetime = Firetime + 1

        If Firetime > 100 Then
            Call Spawnflame()
            Firetime = 0
        End If
        Flame.Left = Flame.Left + FlameSprite.Speed.X

        Call Animateflame()

        Call spawnsmoke()

        Call Smoke()


        If hit(Hiker, Flame) = True And Flame.Visible = True Then
            Namepic = "\pics\explode2.jpg"
            My.Computer.Audio.Play(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\Sounds\Death.wav", AudioPlayMode.Background)
            Call crushhiker()

        End If
    End Sub
    Private Sub spawnsmoke()
        If Flame.Right >= Icefloor(0).Rightedge Then
            FlameSprite.Picknum = 4
            FlameSprite.Speed.X = 0
            FlameSprite.Speed.Y = 0
            FlameSprite.onfloor = True
            Flame.Left = 560 - Flame.Width
        End If
    End Sub
    Private Sub Spawnflame()
        Flame.Visible = True
        Flame.Left = 80
        Flame.Top = 405
        FlameSprite.Speed.X = +5
        FlameSprite.Speed.Y = 0
        FlameSprite.onfloor = True
        FlameSprite.Picknum = 1
        Flame.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\Firesprite1.bmp")
    End Sub
    Private Sub Smoke()
        If FlameSprite.Picknum = 4 Then
            Flame.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\Firesprite4.png")
            FlameSprite.Picknum = 5
        ElseIf FlameSprite.Picknum = 5 Then
            Flame.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\Firesprite5.png")
            FlameSprite.Picknum = 6
        ElseIf FlameSprite.Picknum = 6 Then
            Flame.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\Firesprite6.png")
            FlameSprite.Picknum = 7
        ElseIf FlameSprite.Picknum = 7 Then
            Flame.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\Firesprite7.png")
            FlameSprite.Picknum = 0
        End If
    End Sub
    Private Sub Animateflame()
        If FlameSprite.Picknum = 1 Then
            Flame.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\Firesprite1.bmp")
            FlameSprite.Picknum = 2
        ElseIf FlameSprite.Picknum = 2 Then
            Flame.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\Firesprite2.png")
            FlameSprite.Picknum = 1
        End If
    End Sub
    Private Function SnowSoundeffect(ByVal index As Integer)
        Dim offset As Integer = 10
        If Hiker.Left - offset < Snowball(index).Left And Hiker.Right + offset > Snowball(index).Right Then
            If Hiker.Bottom < Snowball(index).Top Then
                Return True

            End If
        End If
        Return False
    End Function
    Private Sub KABOOM()
        Bombsprite.Elevate = FloorNumber(Bomb1.Top)
        If beekey = True And bombuse = False Then
            beekey = False
            Bomb1.Left = Hiker.Left
            Bomb1.Top = Hiker.Top
            bombtimer = 0
            Bomb1.Visible = True
            Bombsprite.Picknum = 1
            bombuse = True
            Bomb1.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\Bomb.png")
        End If
        bombtimer = bombtimer + 1


        If bombtimer > 100 And Bomb1.Visible = True Then
            Call explosion()

            For index = 0 To BALLNUM
                If Snowsprite(index).Elevate = Bombsprite.Elevate Then
                    Snowball(index).Visible = False
                End If
            Next

            If HikerSprite.Elevate = Bombsprite.Elevate Then

                My.Computer.Audio.Play(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\Sounds\Death.wav", AudioPlayMode.Background)
                Namepic = "\pics\Explode3.jpg"
                Call crushhiker()
            End If

        End If
    End Sub
    Private Sub explosion()
        If Bombsprite.Picknum = 1 Then
            Bomb1.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\Explode1.jpg")
            Bombsprite.Picknum = 2
        ElseIf Bombsprite.Picknum = 2 Then
            Bomb1.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\Explode2.jpg")
            Bombsprite.Picknum = 3
        ElseIf Bombsprite.Picknum = 3 Then
            Bomb1.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\Explode3.jpg")
            Bomb1.Visible = False
        End If
        If Bomb1.Visible = False Then
            Bomb1.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\Bomb.png")
        End If
    End Sub

End Class
