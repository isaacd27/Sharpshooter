﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Game = New System.Windows.Forms.Panel()
        Me.Hiker = New System.Windows.Forms.PictureBox()
        Me.Flame = New System.Windows.Forms.PictureBox()
        Me.life3 = New System.Windows.Forms.PictureBox()
        Me.life2 = New System.Windows.Forms.PictureBox()
        Me.life1 = New System.Windows.Forms.PictureBox()
        Me.life0 = New System.Windows.Forms.PictureBox()
        Me.Scream = New System.Windows.Forms.PictureBox()
        Me.Damsel = New System.Windows.Forms.PictureBox()
        Me.Snowball0 = New System.Windows.Forms.PictureBox()
        Me.Snowball3 = New System.Windows.Forms.PictureBox()
        Me.Snowball2 = New System.Windows.Forms.PictureBox()
        Me.Snowball1 = New System.Windows.Forms.PictureBox()
        Me.ladder7 = New System.Windows.Forms.PictureBox()
        Me.Ballpile = New System.Windows.Forms.PictureBox()
        Me.Yeti = New System.Windows.Forms.PictureBox()
        Me.Ladder0 = New System.Windows.Forms.PictureBox()
        Me.Ladder1 = New System.Windows.Forms.PictureBox()
        Me.Ladder2 = New System.Windows.Forms.PictureBox()
        Me.Ladder3 = New System.Windows.Forms.PictureBox()
        Me.Ladder5 = New System.Windows.Forms.PictureBox()
        Me.Ladder4 = New System.Windows.Forms.PictureBox()
        Me.Ladder6 = New System.Windows.Forms.PictureBox()
        Me.Backdrop = New System.Windows.Forms.PictureBox()
        Me.Timer27 = New System.Windows.Forms.Timer(Me.components)
        Me.Bomb1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Game.SuspendLayout()
        CType(Me.Hiker, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Flame, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.life3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.life2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.life1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.life0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Scream, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Damsel, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Snowball0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Snowball3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Snowball2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Snowball1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ladder7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ballpile, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Yeti, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ladder0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ladder1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ladder2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ladder3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ladder5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ladder4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ladder6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Backdrop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Bomb1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Game
        '
        Me.Game.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Game.Controls.Add(Me.Hiker)
        Me.Game.Controls.Add(Me.PictureBox1)
        Me.Game.Controls.Add(Me.Bomb1)
        Me.Game.Controls.Add(Me.Flame)
        Me.Game.Controls.Add(Me.life3)
        Me.Game.Controls.Add(Me.life2)
        Me.Game.Controls.Add(Me.life1)
        Me.Game.Controls.Add(Me.life0)
        Me.Game.Controls.Add(Me.Scream)
        Me.Game.Controls.Add(Me.Damsel)
        Me.Game.Controls.Add(Me.Snowball0)
        Me.Game.Controls.Add(Me.Snowball3)
        Me.Game.Controls.Add(Me.Snowball2)
        Me.Game.Controls.Add(Me.Snowball1)
        Me.Game.Controls.Add(Me.ladder7)
        Me.Game.Controls.Add(Me.Ballpile)
        Me.Game.Controls.Add(Me.Yeti)
        Me.Game.Controls.Add(Me.Ladder0)
        Me.Game.Controls.Add(Me.Ladder1)
        Me.Game.Controls.Add(Me.Ladder2)
        Me.Game.Controls.Add(Me.Ladder3)
        Me.Game.Controls.Add(Me.Ladder5)
        Me.Game.Controls.Add(Me.Ladder4)
        Me.Game.Controls.Add(Me.Ladder6)
        Me.Game.Controls.Add(Me.Backdrop)
        Me.Game.Location = New System.Drawing.Point(0, 0)
        Me.Game.Name = "Game"
        Me.Game.Size = New System.Drawing.Size(800, 600)
        Me.Game.TabIndex = 0
        '
        'Hiker
        '
        Me.Hiker.Image = CType(resources.GetObject("Hiker.Image"), System.Drawing.Image)
        Me.Hiker.Location = New System.Drawing.Point(88, 428)
        Me.Hiker.Name = "Hiker"
        Me.Hiker.Size = New System.Drawing.Size(24, 34)
        Me.Hiker.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.Hiker.TabIndex = 1
        Me.Hiker.TabStop = False
        '
        'Flame
        '
        Me.Flame.Enabled = False
        Me.Flame.Image = CType(resources.GetObject("Flame.Image"), System.Drawing.Image)
        Me.Flame.Location = New System.Drawing.Point(84, 402)
        Me.Flame.Name = "Flame"
        Me.Flame.Size = New System.Drawing.Size(33, 60)
        Me.Flame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.Flame.TabIndex = 18
        Me.Flame.TabStop = False
        Me.Flame.Visible = False
        '
        'life3
        '
        Me.life3.Image = CType(resources.GetObject("life3.Image"), System.Drawing.Image)
        Me.life3.Location = New System.Drawing.Point(0, 476)
        Me.life3.Name = "life3"
        Me.life3.Size = New System.Drawing.Size(44, 45)
        Me.life3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.life3.TabIndex = 17
        Me.life3.TabStop = False
        '
        'life2
        '
        Me.life2.Image = CType(resources.GetObject("life2.Image"), System.Drawing.Image)
        Me.life2.Location = New System.Drawing.Point(44, 476)
        Me.life2.Name = "life2"
        Me.life2.Size = New System.Drawing.Size(44, 45)
        Me.life2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.life2.TabIndex = 16
        Me.life2.TabStop = False
        '
        'life1
        '
        Me.life1.Image = CType(resources.GetObject("life1.Image"), System.Drawing.Image)
        Me.life1.Location = New System.Drawing.Point(88, 476)
        Me.life1.Name = "life1"
        Me.life1.Size = New System.Drawing.Size(44, 45)
        Me.life1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.life1.TabIndex = 15
        Me.life1.TabStop = False
        '
        'life0
        '
        Me.life0.Image = CType(resources.GetObject("life0.Image"), System.Drawing.Image)
        Me.life0.Location = New System.Drawing.Point(133, 476)
        Me.life0.Name = "life0"
        Me.life0.Size = New System.Drawing.Size(44, 45)
        Me.life0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.life0.TabIndex = 14
        Me.life0.TabStop = False
        '
        'Scream
        '
        Me.Scream.Image = CType(resources.GetObject("Scream.Image"), System.Drawing.Image)
        Me.Scream.Location = New System.Drawing.Point(237, 0)
        Me.Scream.Name = "Scream"
        Me.Scream.Size = New System.Drawing.Size(51, 21)
        Me.Scream.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.Scream.TabIndex = 13
        Me.Scream.TabStop = False
        '
        'Damsel
        '
        Me.Damsel.Image = CType(resources.GetObject("Damsel.Image"), System.Drawing.Image)
        Me.Damsel.Location = New System.Drawing.Point(205, 0)
        Me.Damsel.Name = "Damsel"
        Me.Damsel.Size = New System.Drawing.Size(30, 44)
        Me.Damsel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.Damsel.TabIndex = 1
        Me.Damsel.TabStop = False
        '
        'Snowball0
        '
        Me.Snowball0.Image = CType(resources.GetObject("Snowball0.Image"), System.Drawing.Image)
        Me.Snowball0.Location = New System.Drawing.Point(281, 63)
        Me.Snowball0.Name = "Snowball0"
        Me.Snowball0.Size = New System.Drawing.Size(24, 20)
        Me.Snowball0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.Snowball0.TabIndex = 1
        Me.Snowball0.TabStop = False
        '
        'Snowball3
        '
        Me.Snowball3.Image = CType(resources.GetObject("Snowball3.Image"), System.Drawing.Image)
        Me.Snowball3.Location = New System.Drawing.Point(255, 63)
        Me.Snowball3.Name = "Snowball3"
        Me.Snowball3.Size = New System.Drawing.Size(24, 20)
        Me.Snowball3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.Snowball3.TabIndex = 10
        Me.Snowball3.TabStop = False
        '
        'Snowball2
        '
        Me.Snowball2.Image = CType(resources.GetObject("Snowball2.Image"), System.Drawing.Image)
        Me.Snowball2.Location = New System.Drawing.Point(225, 63)
        Me.Snowball2.Name = "Snowball2"
        Me.Snowball2.Size = New System.Drawing.Size(24, 20)
        Me.Snowball2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.Snowball2.TabIndex = 9
        Me.Snowball2.TabStop = False
        '
        'Snowball1
        '
        Me.Snowball1.Image = CType(resources.GetObject("Snowball1.Image"), System.Drawing.Image)
        Me.Snowball1.Location = New System.Drawing.Point(195, 63)
        Me.Snowball1.Name = "Snowball1"
        Me.Snowball1.Size = New System.Drawing.Size(24, 20)
        Me.Snowball1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.Snowball1.TabIndex = 8
        Me.Snowball1.TabStop = False
        '
        'ladder7
        '
        Me.ladder7.Image = CType(resources.GetObject("ladder7.Image"), System.Drawing.Image)
        Me.ladder7.Location = New System.Drawing.Point(243, 232)
        Me.ladder7.Name = "ladder7"
        Me.ladder7.Size = New System.Drawing.Size(40, 87)
        Me.ladder7.TabIndex = 12
        Me.ladder7.TabStop = False
        '
        'Ballpile
        '
        Me.Ballpile.Image = CType(resources.GetObject("Ballpile.Image"), System.Drawing.Image)
        Me.Ballpile.Location = New System.Drawing.Point(72, 31)
        Me.Ballpile.Name = "Ballpile"
        Me.Ballpile.Size = New System.Drawing.Size(40, 64)
        Me.Ballpile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.Ballpile.TabIndex = 11
        Me.Ballpile.TabStop = False
        '
        'Yeti
        '
        Me.Yeti.Image = CType(resources.GetObject("Yeti.Image"), System.Drawing.Image)
        Me.Yeti.Location = New System.Drawing.Point(118, 29)
        Me.Yeti.Name = "Yeti"
        Me.Yeti.Size = New System.Drawing.Size(80, 64)
        Me.Yeti.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.Yeti.TabIndex = 1
        Me.Yeti.TabStop = False
        '
        'Ladder0
        '
        Me.Ladder0.Image = CType(resources.GetObject("Ladder0.Image"), System.Drawing.Image)
        Me.Ladder0.Location = New System.Drawing.Point(265, 39)
        Me.Ladder0.Name = "Ladder0"
        Me.Ladder0.Size = New System.Drawing.Size(40, 56)
        Me.Ladder0.TabIndex = 7
        Me.Ladder0.TabStop = False
        '
        'Ladder1
        '
        Me.Ladder1.Image = CType(resources.GetObject("Ladder1.Image"), System.Drawing.Image)
        Me.Ladder1.Location = New System.Drawing.Point(471, 89)
        Me.Ladder1.Name = "Ladder1"
        Me.Ladder1.Size = New System.Drawing.Size(40, 63)
        Me.Ladder1.TabIndex = 6
        Me.Ladder1.TabStop = False
        '
        'Ladder2
        '
        Me.Ladder2.Image = CType(resources.GetObject("Ladder2.Image"), System.Drawing.Image)
        Me.Ladder2.Location = New System.Drawing.Point(136, 176)
        Me.Ladder2.Name = "Ladder2"
        Me.Ladder2.Size = New System.Drawing.Size(40, 55)
        Me.Ladder2.TabIndex = 5
        Me.Ladder2.TabStop = False
        '
        'Ladder3
        '
        Me.Ladder3.Image = CType(resources.GetObject("Ladder3.Image"), System.Drawing.Image)
        Me.Ladder3.Location = New System.Drawing.Point(472, 248)
        Me.Ladder3.Name = "Ladder3"
        Me.Ladder3.Size = New System.Drawing.Size(40, 55)
        Me.Ladder3.TabIndex = 4
        Me.Ladder3.TabStop = False
        '
        'Ladder5
        '
        Me.Ladder5.Image = CType(resources.GetObject("Ladder5.Image"), System.Drawing.Image)
        Me.Ladder5.Location = New System.Drawing.Point(323, 313)
        Me.Ladder5.Name = "Ladder5"
        Me.Ladder5.Size = New System.Drawing.Size(40, 83)
        Me.Ladder5.TabIndex = 3
        Me.Ladder5.TabStop = False
        '
        'Ladder4
        '
        Me.Ladder4.Image = CType(resources.GetObject("Ladder4.Image"), System.Drawing.Image)
        Me.Ladder4.Location = New System.Drawing.Point(149, 325)
        Me.Ladder4.Name = "Ladder4"
        Me.Ladder4.Size = New System.Drawing.Size(40, 58)
        Me.Ladder4.TabIndex = 2
        Me.Ladder4.TabStop = False
        '
        'Ladder6
        '
        Me.Ladder6.Image = CType(resources.GetObject("Ladder6.Image"), System.Drawing.Image)
        Me.Ladder6.Location = New System.Drawing.Point(453, 400)
        Me.Ladder6.Name = "Ladder6"
        Me.Ladder6.Size = New System.Drawing.Size(40, 61)
        Me.Ladder6.TabIndex = 1
        Me.Ladder6.TabStop = False
        '
        'Backdrop
        '
        Me.Backdrop.Image = CType(resources.GetObject("Backdrop.Image"), System.Drawing.Image)
        Me.Backdrop.Location = New System.Drawing.Point(3, -2)
        Me.Backdrop.Name = "Backdrop"
        Me.Backdrop.Size = New System.Drawing.Size(640, 480)
        Me.Backdrop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.Backdrop.TabIndex = 0
        Me.Backdrop.TabStop = False
        '
        'Timer27
        '
        '
        'Bomb1
        '
        Me.Bomb1.Image = CType(resources.GetObject("Bomb1.Image"), System.Drawing.Image)
        Me.Bomb1.Location = New System.Drawing.Point(-2, 518)
        Me.Bomb1.Name = "Bomb1"
        Me.Bomb1.Size = New System.Drawing.Size(40, 30)
        Me.Bomb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.Bomb1.TabIndex = 1
        Me.Bomb1.TabStop = False
        Me.Bomb1.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(436, 508)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(100, 50)
        Me.PictureBox1.TabIndex = 19
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(884, 661)
        Me.Controls.Add(Me.Game)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Polar Peril"
        Me.Game.ResumeLayout(False)
        Me.Game.PerformLayout()
        CType(Me.Hiker, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Flame, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.life3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.life2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.life1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.life0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Scream, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Damsel, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Snowball0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Snowball3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Snowball2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Snowball1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ladder7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ballpile, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Yeti, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ladder0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ladder1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ladder2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ladder3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ladder5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ladder4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ladder6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Backdrop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Bomb1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Game As System.Windows.Forms.Panel
    Friend WithEvents Backdrop As System.Windows.Forms.PictureBox
    Friend WithEvents Hiker As System.Windows.Forms.PictureBox
    Friend WithEvents Timer27 As System.Windows.Forms.Timer
    Friend WithEvents Ladder6 As System.Windows.Forms.PictureBox
    Friend WithEvents Ladder0 As System.Windows.Forms.PictureBox
    Friend WithEvents Ladder1 As System.Windows.Forms.PictureBox
    Friend WithEvents Ladder2 As System.Windows.Forms.PictureBox
    Friend WithEvents Ladder3 As System.Windows.Forms.PictureBox
    Friend WithEvents Ladder5 As System.Windows.Forms.PictureBox
    Friend WithEvents Ladder4 As System.Windows.Forms.PictureBox
    Friend WithEvents Snowball1 As System.Windows.Forms.PictureBox
    Friend WithEvents Snowball0 As System.Windows.Forms.PictureBox
    Friend WithEvents Snowball2 As System.Windows.Forms.PictureBox
    Friend WithEvents Snowball3 As System.Windows.Forms.PictureBox
    Protected WithEvents Yeti As System.Windows.Forms.PictureBox
    Friend WithEvents Ballpile As System.Windows.Forms.PictureBox
    Friend WithEvents ladder7 As System.Windows.Forms.PictureBox
    Friend WithEvents Scream As System.Windows.Forms.PictureBox
    Friend WithEvents Damsel As System.Windows.Forms.PictureBox
    Friend WithEvents life3 As System.Windows.Forms.PictureBox
    Friend WithEvents life2 As System.Windows.Forms.PictureBox
    Friend WithEvents life1 As System.Windows.Forms.PictureBox
    Friend WithEvents life0 As System.Windows.Forms.PictureBox
    Friend WithEvents Flame As System.Windows.Forms.PictureBox
    Friend WithEvents Bomb1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox

End Class
