﻿Public Class mainMenu

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        easymode = False
        Me.Close()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        quit = True
        Me.Close()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Easymode = True
        Me.Close()
    End Sub

    Private Sub mainMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        My.Computer.Audio.Play(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\Sounds\intro1.wav", AudioPlayMode.Background)
    End Sub


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        My.Computer.Audio.Play(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\Sounds\bacmusic.wav", AudioPlayMode.Background)
    End Sub
End Class