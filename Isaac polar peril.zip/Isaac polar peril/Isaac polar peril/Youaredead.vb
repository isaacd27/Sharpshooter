﻿Public Class Youaredead

    Private Sub Youaredead_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Changeable.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & Namepic)
    End Sub

    Private Sub Tryagain_Click(sender As Object, e As EventArgs) Handles Tryagain.Click
        Me.Close()
    End Sub

    Private Sub Coward_Click(sender As Object, e As EventArgs) Handles Coward.Click
        Quit = True
        Me.Close()
    End Sub

    
End Class