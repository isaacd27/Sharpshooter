﻿Public Class Gameover
    Dim Throwtimer As Integer
    Const BALLTICK As Integer = 30
    Private Sub deathdance()
        Throwtimer = Throwtimer + 1

        If Throwtimer > BALLTICK - 2 Then
            Yeti.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\bobsmiling.jpg")
        ElseIf Throwtimer > BALLTICK / 2 Then
            Yeti.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\bobdancing2.jpg")
        ElseIf Throwtimer > BALLTICK / 4 Then
            Yeti.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\bobdancing.jpg")
        ElseIf Throwtimer > BALLTICK / 8 Then
            Yeti.Image = Image.FromFile(IO.Path.GetDirectoryName(Application.ExecutablePath) & "\pics\bobstanding.jpg")
        End If
        If Throwtimer = BALLTICK Then
            Throwtimer = 0
        End If
    End Sub

    Private Sub timerDance_Tick(sender As Object, e As EventArgs) Handles timerDance.Tick
        Call deathdance()
    End Sub

    Private Sub Urdead_Click(sender As Object, e As EventArgs) Handles Urdead.Click
        quit = True
        Me.Close()
    End Sub

    Private Sub Gameover_Load(sender As Object, e As EventArgs) Handles Me.Load
        Throwtimer = 0
        timerDance.Start()
    End Sub


    
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        easymode = True
        Me.Close()
    End Sub
End Class