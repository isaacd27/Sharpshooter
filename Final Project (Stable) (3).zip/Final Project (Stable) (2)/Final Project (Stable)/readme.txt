GAME BY ISAAC DAVIS

Arrow keys to move
Z to interact with small red squares (aka levers)
X for special ability
Spacebar to move on to next robot
R to restart level

If you are stuck on a level press r, it's possible you accidentally used up a robot.

ROBOTS
Gray - Box pusher (able to push boxes by walking into them)
Green - Grapple bot (pulls boxes toward itself and can grapple onto surfaces
Red/Orange - Push bot (pushes boxes away from itself)
Brown - Hover bot (can ignore gravity)



the green/gray thing is the exit (green means closed)

levers are small red squares

buttons are red but green when you step on them.

platforms are red rectangles that touch the surface of the ground(most of the time) unlike buttons

