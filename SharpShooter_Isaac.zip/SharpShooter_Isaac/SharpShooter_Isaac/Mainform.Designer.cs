﻿namespace SharpShooter_Isaac
{
    partial class Mainform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Mainform));
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.MainMenu = new System.Windows.Forms.MenuStrip();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.weaponSelectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pistolToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rapidToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sniperToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.superblauncherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.option3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hp100ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.noEnemiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Title = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Box1 = new System.Windows.Forms.PictureBox();
            this.Box3 = new System.Windows.Forms.PictureBox();
            this.Box4 = new System.Windows.Forms.PictureBox();
            this.shopToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Hip = new System.Windows.Forms.Label();
            this.Po = new System.Windows.Forms.Label();
            this.MainMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Title)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box4)).BeginInit();
            this.SuspendLayout();
            // 
            // timer
            // 
            this.timer.Interval = 45;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // MainMenu
            // 
            this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem});
            this.MainMenu.Location = new System.Drawing.Point(0, 0);
            this.MainMenu.Name = "MainMenu";
            this.MainMenu.Size = new System.Drawing.Size(800, 24);
            this.MainMenu.TabIndex = 0;
            this.MainMenu.Text = "Main Menu";
            this.MainMenu.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.MainMenu_ItemClicked);
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.resetToolStripMenuItem,
            this.weaponSelectToolStripMenuItem,
            this.option3ToolStripMenuItem,
            this.shopToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.optionsToolStripMenuItem.Text = "Options";
            this.optionsToolStripMenuItem.Click += new System.EventHandler(this.optionsToolStripMenuItem_Click);
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.resetToolStripMenuItem.Text = "Reset";
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.resetToolStripMenuItem_Click);
            // 
            // weaponSelectToolStripMenuItem
            // 
            this.weaponSelectToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pistolToolStripMenuItem,
            this.rapidToolStripMenuItem,
            this.sniperToolStripMenuItem,
            this.superblauncherToolStripMenuItem});
            this.weaponSelectToolStripMenuItem.Name = "weaponSelectToolStripMenuItem";
            this.weaponSelectToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.weaponSelectToolStripMenuItem.Text = "Weapon select";
            this.weaponSelectToolStripMenuItem.Click += new System.EventHandler(this.weaponSelectToolStripMenuItem_Click);
            // 
            // pistolToolStripMenuItem
            // 
            this.pistolToolStripMenuItem.Name = "pistolToolStripMenuItem";
            this.pistolToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.pistolToolStripMenuItem.Text = "Pistol";
            this.pistolToolStripMenuItem.Click += new System.EventHandler(this.pistolToolStripMenuItem_Click);
            // 
            // rapidToolStripMenuItem
            // 
            this.rapidToolStripMenuItem.Name = "rapidToolStripMenuItem";
            this.rapidToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.rapidToolStripMenuItem.Text = "Rapid";
            this.rapidToolStripMenuItem.Click += new System.EventHandler(this.rapidToolStripMenuItem_Click);
            // 
            // sniperToolStripMenuItem
            // 
            this.sniperToolStripMenuItem.Name = "sniperToolStripMenuItem";
            this.sniperToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.sniperToolStripMenuItem.Text = "Sniper";
            this.sniperToolStripMenuItem.Click += new System.EventHandler(this.sniperToolStripMenuItem_Click);
            // 
            // superblauncherToolStripMenuItem
            // 
            this.superblauncherToolStripMenuItem.Name = "superblauncherToolStripMenuItem";
            this.superblauncherToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.superblauncherToolStripMenuItem.Text = "Superblauncher";
            this.superblauncherToolStripMenuItem.Click += new System.EventHandler(this.superblauncherToolStripMenuItem_Click);
            // 
            // option3ToolStripMenuItem
            // 
            this.option3ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hp100ToolStripMenuItem,
            this.noEnemiesToolStripMenuItem});
            this.option3ToolStripMenuItem.Name = "option3ToolStripMenuItem";
            this.option3ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.option3ToolStripMenuItem.Text = "Testing";
            // 
            // hp100ToolStripMenuItem
            // 
            this.hp100ToolStripMenuItem.Name = "hp100ToolStripMenuItem";
            this.hp100ToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.hp100ToolStripMenuItem.Text = "Hp = 100";
            this.hp100ToolStripMenuItem.Click += new System.EventHandler(this.hp100ToolStripMenuItem_Click);
            // 
            // noEnemiesToolStripMenuItem
            // 
            this.noEnemiesToolStripMenuItem.Name = "noEnemiesToolStripMenuItem";
            this.noEnemiesToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.noEnemiesToolStripMenuItem.Text = "No enemies";
            this.noEnemiesToolStripMenuItem.Click += new System.EventHandler(this.noEnemiesToolStripMenuItem_Click);
            // 
            // Title
            // 
            this.Title.Image = ((System.Drawing.Image)(resources.GetObject("Title.Image")));
            this.Title.Location = new System.Drawing.Point(107, 27);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(568, 161);
            this.Title.TabIndex = 1;
            this.Title.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(293, 344);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(141, 94);
            this.button1.TabIndex = 2;
            this.button1.Text = "Start";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Box1
            // 
            this.Box1.Image = ((System.Drawing.Image)(resources.GetObject("Box1.Image")));
            this.Box1.Location = new System.Drawing.Point(209, 242);
            this.Box1.Name = "Box1";
            this.Box1.Size = new System.Drawing.Size(64, 64);
            this.Box1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Box1.TabIndex = 3;
            this.Box1.TabStop = false;
            // 
            // Box3
            // 
            this.Box3.Image = ((System.Drawing.Image)(resources.GetObject("Box3.Image")));
            this.Box3.Location = new System.Drawing.Point(337, 271);
            this.Box3.Name = "Box3";
            this.Box3.Size = new System.Drawing.Size(8, 8);
            this.Box3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Box3.TabIndex = 5;
            this.Box3.TabStop = false;
            // 
            // Box4
            // 
            this.Box4.Image = ((System.Drawing.Image)(resources.GetObject("Box4.Image")));
            this.Box4.Location = new System.Drawing.Point(398, 242);
            this.Box4.Name = "Box4";
            this.Box4.Size = new System.Drawing.Size(64, 64);
            this.Box4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Box4.TabIndex = 6;
            this.Box4.TabStop = false;
            // 
            // shopToolStripMenuItem
            // 
            this.shopToolStripMenuItem.Name = "shopToolStripMenuItem";
            this.shopToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.shopToolStripMenuItem.Text = "Shop";
            this.shopToolStripMenuItem.Click += new System.EventHandler(this.shopToolStripMenuItem_Click);
            // 
            // Hip
            // 
            this.Hip.AutoSize = true;
            this.Hip.ForeColor = System.Drawing.Color.Red;
            this.Hip.Location = new System.Drawing.Point(12, 27);
            this.Hip.Name = "Hip";
            this.Hip.Size = new System.Drawing.Size(21, 13);
            this.Hip.TabIndex = 7;
            this.Hip.Text = "Hp";
            this.Hip.Click += new System.EventHandler(this.label1_Click);
            // 
            // Po
            // 
            this.Po.AutoSize = true;
            this.Po.ForeColor = System.Drawing.Color.Red;
            this.Po.Location = new System.Drawing.Point(681, 24);
            this.Po.Name = "Po";
            this.Po.Size = new System.Drawing.Size(35, 13);
            this.Po.TabIndex = 8;
            this.Po.Text = "points";
            // 
            // Mainform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Po);
            this.Controls.Add(this.Hip);
            this.Controls.Add(this.Box4);
            this.Controls.Add(this.Box3);
            this.Controls.Add(this.Box1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Title);
            this.Controls.Add(this.MainMenu);
            this.MainMenuStrip = this.MainMenu;
            this.Name = "Mainform";
            this.Text = "Sharpshooter";
            this.MainMenu.ResumeLayout(false);
            this.MainMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Title)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Box4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.MenuStrip MainMenu;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem weaponSelectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pistolToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rapidToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sniperToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem superblauncherToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem option3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hp100ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem noEnemiesToolStripMenuItem;
        private System.Windows.Forms.PictureBox Title;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox Box1;
        private System.Windows.Forms.PictureBox Box3;
        private System.Windows.Forms.PictureBox Box4;
        private System.Windows.Forms.ToolStripMenuItem shopToolStripMenuItem;
        private System.Windows.Forms.Label Hip;
        private System.Windows.Forms.Label Po;
    }
}

