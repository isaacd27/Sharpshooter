﻿using SharpShooter_Isaac.Game_Objects;
using SharpShooter_Isaac.Game_Objects.Weapons;
//using SharpShooter_Isaac.Game_Objects.Explosion;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;


namespace SharpShooter_Isaac
{
    public partial class Mainform : Form
    {
        public Boolean Quit;
        public static Player player1;
        public static List<bullet> bulletlist;
        public static int Points = 0; 
        public static List<Soilder> Enemylist;
        public static List<Wall> wallist;
        public static List<Explosion> exlist;
        public static List<Weapon> weplist;
        public static List<Medkit> medlist;
        //public static bullet bullet1;
        public static Point Voffset ;
        Gameover go;
        Itemshop it;
        

        Graphics windowsGraphics;
        Graphics stageninja;
        Bitmap offimage;
        public Picture gameoverScreen;
        public Picture winscreen;
        public Mainform()
        {
            InitializeComponent();

            windowsGraphics = this.CreateGraphics();
            offimage = new Bitmap(this.Width, this.Height);
            stageninja = Graphics.FromImage(offimage);
            this.Paint += new PaintEventHandler(DrawGame);
            init();
        }

        public void init()
        {
            go = new Gameover(this);
           
            //Hip.Text = player1.hp.ToString();
            Quit = false;
            //player1.pic = new Picture("Images/Player_1.png", new PointF(500,300));
            level.createlevel();
            //enemydummy = new Enemy(new PointF(200, 300));
            
           // bullet1 = new bullet(new PointF(500,300));
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(player1.KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(player1.KeyUp);

           


           



            gameoverScreen = new Picture("Images/GameOver.png", new PointF(this.Width / 2, this.Height / 3), 1, 1);
            winscreen = new Picture("Images/victory.png", new PointF(this.Width / 2, this.Height / 3), 1, 1); 


        }


        public void DrawGame(Object sender, PaintEventArgs e)
        {

            Hip.Text = "Hp: " + (player1.hp);
            Po.Text = "Points: " + Points.ToString();

            if (timer.Enabled == true)
            {
                stageninja.Clear(Color.Black);
                player1.draw(stageninja);
                // enemydummy.draw(windowsGraphics);

                //bullet1.draw(windowsGraphics);
                foreach (bullet b in bulletlist)
                {
                    b.draw(stageninja);
                }

                foreach (Wall w in wallist)
                {
                    w.draw(stageninja);
                }

                foreach (Weapon w in weplist)
                {
                    w.Draw(stageninja);
                }
                
                foreach (Medkit m in medlist)
                {
                    m.Draw(stageninja);
                }

                foreach (Soilder i in Enemylist)
                {
                    /*
                    if (i.killed == true)
                    {
                        Console.WriteLine("Enemey" + i.ToString());
                    }*/
                    i.draw(stageninja);
                }

                foreach (Explosion i in exlist)
                {
                    i.draw(stageninja);
                }

                if (Mainform.Enemylist.Count == 0)
                {
                    winscreen.Draw(stageninja);
                }

                if (player1.killed && timer.Interval != 0)
                {
                   
                    timer.Stop();
                    //timer.Interval = 0;
                   
                    go.ShowDialog();
                    if (this.Quit == true)
                    {
                        this.Close();
                        go.Close();
                    }
                   
                    timer.Start();
                   // init();
                    

                    //gameoverScreen.Draw(stageninja);
                    //Explosion playerdied = new Explosion(player1.location);
                    //playerdied.Draw(stageNinja);
                }


                windowsGraphics.DrawImage(offimage, new Point(0, 0));
            }
            else
            {
                return;
            }
            
        }

        private void timer_Tick(object sender, EventArgs e)
        {
           
            player1.Update(timer.Interval);
            player1.updateweapon(timer.Interval);

            //Console.WriteLine(bulletlist.Count.ToString());
            for (int i = 0; i < bulletlist.Count; i++)
            {
                bulletlist[i].Update(timer.Interval);
            }
            for (int i = 0; i < Enemylist.Count; i++)
            {
                Enemylist[i].updateweapon(timer.Interval);
                Enemylist[i].Update(timer.Interval);
                 //broken

            }

            for (int i= 0; i < weplist.Count; i++)
            {
                weplist[i].update(timer.Interval);
            }


            for(int i = 0; i< exlist.Count; i++)
            {
                exlist[i].Update(timer.Interval);

            }

            for(int i = 0; i< medlist.Count;i++)
            {
                medlist[i].update(timer.Interval);
            }

            if (player1.killed == true)
                {
                player1.location.Y = -9999;
            }
            Voffset.X = (int)player1.location.X - this.Width / 2;
            Voffset.Y = (int)player1.location.Y - this.Height / 2;
            OnPaint(new PaintEventArgs(windowsGraphics, new Rectangle (0,0, this.Width, this.Height)));

           

        }

        private void optionsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        public void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            init();
        }

        private void weaponSelectToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void pistolToolStripMenuItem_Click(object sender, EventArgs e)
        {
            player1.currentweapon = new Pistol(player1.location);
        }

        private void rapidToolStripMenuItem_Click(object sender, EventArgs e)
        {
            player1.currentweapon = new Rapid(player1.location);
        }

        private void sniperToolStripMenuItem_Click(object sender, EventArgs e)
        {
            player1.currentweapon = new Sniper(player1.location);

        }

        private void superblauncherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            player1.currentweapon = new Superlaunch(player1.location);
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void hp100ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            player1.hp = 100; 
        }

        private void noEnemiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Enemylist.Clear();
        }

        private void MainMenu_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer.Enabled = true;
            init();
            Title.Hide();
            Box1.Hide();
            Box3.Hide();
            Box4.Hide();
            button1.Enabled = false;
            button1.Hide();


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void shopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            it = new Itemshop(this);
            timer.Stop();
            it.ShowDialog();
            timer.Start();
        }
    }
}
