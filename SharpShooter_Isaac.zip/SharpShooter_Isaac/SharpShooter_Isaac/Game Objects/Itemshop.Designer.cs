﻿namespace SharpShooter_Isaac.Game_Objects
{
    partial class Itemshop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Itemshop));
            this.Close = new System.Windows.Forms.Button();
            this.Rapidbuy = new System.Windows.Forms.Button();
            this.sniperbuy = new System.Windows.Forms.Button();
            this.Superbuy = new System.Windows.Forms.Button();
            this.medbuy = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.medbay = new System.Windows.Forms.Label();
            this.rapidcost = new System.Windows.Forms.Label();
            this.Snipercost = new System.Windows.Forms.Label();
            this.supercost = new System.Windows.Forms.Label();
            this.Po = new System.Windows.Forms.Label();
            this.buy = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // Close
            // 
            this.Close.Location = new System.Drawing.Point(-1, -2);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(75, 22);
            this.Close.TabIndex = 0;
            this.Close.Text = "Close";
            this.Close.UseVisualStyleBackColor = true;
            this.Close.Click += new System.EventHandler(this.button1_Click);
            // 
            // Rapidbuy
            // 
            this.Rapidbuy.Location = new System.Drawing.Point(117, 266);
            this.Rapidbuy.Name = "Rapidbuy";
            this.Rapidbuy.Size = new System.Drawing.Size(75, 23);
            this.Rapidbuy.TabIndex = 1;
            this.Rapidbuy.Text = "Rapid";
            this.Rapidbuy.UseVisualStyleBackColor = true;
            this.Rapidbuy.Click += new System.EventHandler(this.Rapidbuy_Click);
            // 
            // sniperbuy
            // 
            this.sniperbuy.Location = new System.Drawing.Point(243, 266);
            this.sniperbuy.Name = "sniperbuy";
            this.sniperbuy.Size = new System.Drawing.Size(75, 23);
            this.sniperbuy.TabIndex = 2;
            this.sniperbuy.Text = "Sniper";
            this.sniperbuy.UseVisualStyleBackColor = true;
            this.sniperbuy.Click += new System.EventHandler(this.sniperbuy_Click);
            // 
            // Superbuy
            // 
            this.Superbuy.Location = new System.Drawing.Point(382, 266);
            this.Superbuy.Name = "Superbuy";
            this.Superbuy.Size = new System.Drawing.Size(75, 23);
            this.Superbuy.TabIndex = 3;
            this.Superbuy.Text = "Superball";
            this.Superbuy.UseVisualStyleBackColor = true;
            this.Superbuy.Click += new System.EventHandler(this.Superbuy_Click);
            // 
            // medbuy
            // 
            this.medbuy.Location = new System.Drawing.Point(541, 266);
            this.medbuy.Name = "medbuy";
            this.medbuy.Size = new System.Drawing.Size(75, 23);
            this.medbuy.TabIndex = 4;
            this.medbuy.Text = "Medpack";
            this.medbuy.UseVisualStyleBackColor = true;
            this.medbuy.Click += new System.EventHandler(this.medbuy_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(129, 201);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(49, 50);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(230, 201);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 50);
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(382, 201);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(51, 59);
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(551, 204);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(52, 47);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 8;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // medbay
            // 
            this.medbay.AutoSize = true;
            this.medbay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.medbay.Location = new System.Drawing.Point(540, 304);
            this.medbay.Name = "medbay";
            this.medbay.Size = new System.Drawing.Size(67, 13);
            this.medbay.TabIndex = 9;
            this.medbay.Text = "Cost: 10,000";
            this.medbay.Click += new System.EventHandler(this.medbay_Click);
            // 
            // rapidcost
            // 
            this.rapidcost.AutoSize = true;
            this.rapidcost.ForeColor = System.Drawing.Color.Red;
            this.rapidcost.Location = new System.Drawing.Point(126, 304);
            this.rapidcost.Name = "rapidcost";
            this.rapidcost.Size = new System.Drawing.Size(52, 13);
            this.rapidcost.TabIndex = 10;
            this.rapidcost.Text = "Cost: 300";
            // 
            // Snipercost
            // 
            this.Snipercost.AutoSize = true;
            this.Snipercost.ForeColor = System.Drawing.Color.Red;
            this.Snipercost.Location = new System.Drawing.Point(266, 304);
            this.Snipercost.Name = "Snipercost";
            this.Snipercost.Size = new System.Drawing.Size(52, 13);
            this.Snipercost.TabIndex = 11;
            this.Snipercost.Text = "Cost: 600";
            // 
            // supercost
            // 
            this.supercost.AutoSize = true;
            this.supercost.ForeColor = System.Drawing.Color.Red;
            this.supercost.Location = new System.Drawing.Point(405, 304);
            this.supercost.Name = "supercost";
            this.supercost.Size = new System.Drawing.Size(67, 13);
            this.supercost.TabIndex = 12;
            this.supercost.Text = "Cost: 30,000";
            // 
            // Po
            // 
            this.Po.AutoSize = true;
            this.Po.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Po.Location = new System.Drawing.Point(581, 9);
            this.Po.Name = "Po";
            this.Po.Size = new System.Drawing.Size(36, 13);
            this.Po.TabIndex = 13;
            this.Po.Text = "Points";
            this.Po.Click += new System.EventHandler(this.label1_Click);
            // 
            // buy
            // 
            this.buy.AutoSize = true;
            this.buy.ForeColor = System.Drawing.Color.Red;
            this.buy.Location = new System.Drawing.Point(322, 362);
            this.buy.Name = "buy";
            this.buy.Size = new System.Drawing.Size(111, 13);
            this.buy.TabIndex = 14;
            this.buy.Text = "Welcome to the shop!";
            // 
            // Itemshop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buy);
            this.Controls.Add(this.Po);
            this.Controls.Add(this.supercost);
            this.Controls.Add(this.Snipercost);
            this.Controls.Add(this.rapidcost);
            this.Controls.Add(this.medbay);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.medbuy);
            this.Controls.Add(this.Superbuy);
            this.Controls.Add(this.sniperbuy);
            this.Controls.Add(this.Rapidbuy);
            this.Controls.Add(this.Close);
            this.Name = "Itemshop";
            this.Text = "Itemshop";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Close;
        private System.Windows.Forms.Button Rapidbuy;
        private System.Windows.Forms.Button sniperbuy;
        private System.Windows.Forms.Button Superbuy;
        private System.Windows.Forms.Button medbuy;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label medbay;
        private System.Windows.Forms.Label rapidcost;
        private System.Windows.Forms.Label Snipercost;
        private System.Windows.Forms.Label supercost;
        private System.Windows.Forms.Label Po;
        private System.Windows.Forms.Label buy;
    }
}