﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpShooter_Isaac.Game_Objects.Weapons
{
    public abstract class Weapon
    {

        public Picture pic;
        public PointF location;

        public float bulletspeed;
        public int delay;
        public float bulletstartdist;
        public int angle;
        public int timesincelastshot;
        public bool onGround = false;
        public int radius;
        public int damage;


        //location
        //picture
        //firerate
        //bullet start dist




        public Weapon(string image, PointF Location)
        {


            location = Location;
            pic = new Picture(image, location, 1, 1);
            this.radius = pic.bitmap.Width / 2;

        }

        public void Draw(Graphics g)
        {

            pic.Angle = angle;
            pic.location.X = location.X - Mainform.Voffset.X;
            pic.location.Y = location.Y - Mainform.Voffset.Y;
            pic.Draw(g);
        }

        public void update(int time)
        {
            timesincelastshot += time;
            //istouching();
            if (istouching(Mainform.player1) && this.onGround)
            {
                this.onGround = false;
                Mainform.player1.currentweapon = this;
                Mainform.weplist.Remove(this);
                
            }
        }




        public void Fire(Soilder s)
        {


            if (timesincelastshot < delay)
            {
                return;

            }

            timesincelastshot = 0;
            float x = (float)Math.Cos(angle / 180f * Math.PI);
            float y = -(float)Math.Sin(angle / 180f * Math.PI);
            bullet bullet = CreateBullet(s);
            // Console.WriteLine("Create bullet called");
            //CreateBullet(s);
            bullet.location.X = location.X + x * bulletstartdist;
            bullet.location.Y = location.Y + y * bulletstartdist;
            //this.location.X = this.location.X + x 

            bullet.velocity.X = x * bulletspeed;
            bullet.velocity.Y = y * bulletspeed;


        }



        public abstract bullet CreateBullet(Soilder fire);

        //return new bullet(this.location, Soilder, "Images/Bullet1.png");






        public bool istouching(Soilder s)
        {
            float side1 = (s.location.X - this.location.X) * (s.location.X - this.location.X);
            float side2 = (s.location.Y - this.location.Y) * (s.location.Y - this.location.Y);

            double side3 = Math.Sqrt(side1 + side2);




            if (side3 < this.radius + s.radius)
            {
                Console.WriteLine("Hit soilder");
                return true;

            }
            else
            {
                //  Console.WriteLine("Checked istouching");
                return false;
            }
        }
    }
}
