﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpShooter_Isaac.Game_Objects.Weapons
{
    public class Rapid:Weapon
    {



        public Rapid(PointF location) : base("Images/RapidGun.png",location)
        {
            bulletspeed = 15f;
            bulletstartdist = 10f;
            delay = 200;


        }


        public override bullet CreateBullet(Soilder fire)
        {
           // Console.WriteLine("Rapid bullet");
            return new bullet(this.location, fire,"Images/Bullet3.png",1); //makes a bullet with the image bullet3
        }










    }
}
