﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpShooter_Isaac.Game_Objects.Weapons
{
    public class Superlaunch:Weapon
    {


        public Superlaunch(PointF location) : base("Images/SuperBallLauncher.png", location)
        {
            bulletspeed = 50f;
            bulletstartdist = 15f;
            delay = 800;
        }



        public override bullet CreateBullet(Soilder fire)
        {
            return new bullet(this.location,fire,"Images/SuperBall.png",10);
        }
    }
}
