﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpShooter_Isaac.Game_Objects.Weapons
{
    public class Pistol:Weapon
    {


        public Pistol(PointF location)
        
            :base("Images/Pistol.png",location){

            bulletspeed = 15f;
            bulletstartdist = 10f;
            delay = 600;



            }
        





        public override bullet CreateBullet(Soilder fire)
        {
            return new bullet(this.location, fire, "Images/Bullet1.png",2);
        }



    }
}
