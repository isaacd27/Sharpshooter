﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpShooter_Isaac.Game_Objects;

using System.Drawing;

using SharpShooter_Isaac.Game_Objects.Weapons;

namespace SharpShooter_Isaac.Game_Objects
{
    public class Soilder
    {




        public Picture pic;
        public PointF location;
        public float facingAngle = 0f;
        public float Turndirection = 0f;
        public int Walkdirection = 0; //direction you walk + forward
        public PointF velocity;
        public int moveSpeed = 7;


        public Boolean isfiring = false;
        /*
        public float bulletspeed = 15f;
        public int fireDelay = 500;
        public int timesincelastshot = 500;
        public float bulletstartdist = 30f;
        */
        public int radius;
        public int hp = 10;
        public Boolean killed = false;
        public bool hitflicker = false;
        public int hittimer = 0;

        public Weapons.Weapon currentweapon;

        public Soilder(String imageroute, PointF locationin)
        // pictures/
        {

            pic = new Picture(imageroute, locationin, 4, 60);

            this.location = locationin;
            velocity = new PointF();

            Random randy = new Random((int)DateTime.Now.Ticks);
            facingAngle = randy.Next(360);
            radius = pic.bitmap.Width / 2;
        }



        public void draw(Graphics G)
        {

            if (this.killed)
            {

                return;
            }

           
            pic.Angle = facingAngle;

            if (!hitflicker)
            {
                pic.location.X = location.X - Mainform.Voffset.X;
                pic.location.Y = location.Y - Mainform.Voffset.Y;
                //pic.location.Z = location.Z - Mainform.Voffset.Z;

                pic.Draw(G);
               
            }
            currentweapon.Draw(G);
        }


        public virtual void Update(int time)
        {
            facingAngle += ((float)(time)) / 3 * Turndirection;



            //updateweapon(time);



            velocity.X = (float)Math.Cos(facingAngle / 180f * Math.PI) * Walkdirection * moveSpeed;
            velocity.Y = -(float)Math.Sin(facingAngle / 180f * Math.PI) * Walkdirection * moveSpeed;


            Move();
            if (velocity.X != 0 || velocity.Y != 0)
            {
                pic.update(time);
            }

            //timesincelastshot += time;


            if (isfiring == true)
            {

                currentweapon.Fire(this);
            }

            if (hp <= 0)
            {

                killed = true;
              //  if (this == Enemy)
              //  {

              //  }
                Explosion e = new Explosion(this.location);

                return;

            }

            if (hittimer > 0)
            {

                hittimer -= 1;
                hitflicker = !hitflicker;
            }
            else
            {
                hitflicker = false;
            }

            foreach (Wall w in Mainform.wallist)
            {

                PointF touchpoint = new PointF();

                if (this.istouching(w, ref touchpoint))
                {
                    Pushout(touchpoint);
                }

            }
        }

        /*public void KeyDown(Object Sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                Turndirection = 1;
            }
            if (e.KeyCode == Keys.Right)
            {
                Turndirection = -1;
            }
            if (e.KeyCode == Keys.Up)
            {
                Walkdirection = 1;

            }
            if (e.KeyCode == Keys.Down)
            {
                Walkdirection = -1;
            }
            if (e.KeyCode == Keys.Space)
            {
                isfiring = true;

            }


        }


       public void KeyUp(Object Sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Right)
            {
                Turndirection = 0;
            }
            else if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down)
            {
                Walkdirection = 0;
            }
            else if (e.KeyCode == Keys.Space)
            {
                isfiring = false;
            }
       }*/

        public void Move()
        {
            location.X += velocity.X;
            location.Y += velocity.Y;

            // crtl+alt + click to write more then one line
            // crtl+alt + click to write more then one line
        }


        public void damage(int damagein)
        {
            hp -= damagein;
            hittimer = 4;

        }


        public bool istouching(Wall w, ref PointF touchpoint)
        {

            PointF nearestpoint = w.nearest(this.location);

            float side1 = (nearestpoint.X - this.location.X) * (nearestpoint.X - this.location.X);
            float side2 = (nearestpoint.Y - this.location.Y) * (nearestpoint.Y - this.location.Y);

            double side3 = Math.Sqrt(side1 + side2);




            if (side3 < this.radius)
            {
                touchpoint = nearestpoint;
                return true;
            }
            else
            {
                return false;
            }




        }



        public void Pushout(PointF p)
        {

            float side1 = (p.X - this.location.X) * (p.X - this.location.X);
            float side2 = (p.Y - this.location.Y) * (p.Y - this.location.Y);

            float side3 = (float)Math.Sqrt(side1 + side2);

            if (side3 == 0)
            {
                return;
            }

            float desiredDist = this.radius + 1;


            float proportion = desiredDist / side3;

            PointF move = new PointF(this.location.X - p.X, this.location.Y - p.Y);

            move.X *= proportion;
            move.Y *= proportion;

            this.location.X = p.X + move.X;
            this.location.Y = p.Y + move.Y;


        }

        public void updateweapon(int time)
        {



            // float side1 = (currentweapon.location.X - this.location.X) * (currentweapon.location.X - this.location.X);
            // float side2 = (currentweapon.location.Y - this.location.Y) * (currentweapon.location.Y - this.location.Y);

            float xoffset = (float)Math.Cos(this.facingAngle / 180f * Math.PI) * 32f;
            float yoffset = -(float)Math.Sin(this.facingAngle / 180f * Math.PI) * 32f;

            currentweapon.location.X = this.location.X + xoffset; //- Mainform.Voffset.X;
            currentweapon.location.Y = this.location.Y + yoffset; //- Mainform.Voffset.Y;

            currentweapon.angle = (int)facingAngle;


            currentweapon.update(time);

        }












    }




}

