﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;

namespace SharpShooter_Isaac
{
    public class Picture
    {
        public Bitmap bitmap;
        public PointF location;
        public float Angle = 0f;
        public PointF offset;



        public int frame = 0;
        public int framecount;
        public int timeperframe;
        public int animcounter;
        public Picture(String filename, PointF location, int frames, int flipTime)
    {
            framecount = frames;
            timeperframe = flipTime;
            bitmap = new Bitmap(filename);
            this.location = location;
            offset = new PointF(bitmap.Width / 2f, bitmap.Height / framecount / 2f); 
    }


        public void Draw(Graphics g)
        {


            Point drawLocation = new Point((int)(location.X - offset.X), (int) (location.Y - offset.Y));


            Matrix m = new Matrix();
            m.RotateAt(-Angle, location);  //rotates by given point
            g.Transform = m;  //sets the 'drawing transform' to this rotation

            g.DrawImage(bitmap, new Rectangle(drawLocation.X, drawLocation.Y, bitmap.Width, bitmap.Height/framecount),
             new Rectangle(0,frame * bitmap.Height/framecount,bitmap.Width,bitmap.Height/framecount), GraphicsUnit.Pixel); //animates i think, i don't really know
        }

        public void update(int time)
        {
            animcounter += time; 

            frame += 1;
            if (animcounter >= this.timeperframe)
            {
                if (frame >= framecount)
                {
                    frame = 0;
                }
            }
        }
       
        

    }
}
