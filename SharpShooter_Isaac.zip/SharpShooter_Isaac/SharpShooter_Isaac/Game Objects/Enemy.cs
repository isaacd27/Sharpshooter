﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.VisualStyles;
using SharpShooter_Isaac.Game_Objects;

using SharpShooter_Isaac.Game_Objects.Weapons;

namespace SharpShooter_Isaac.Game_Objects
{
    public class Enemy : Soilder
    {

        int directionChangeCounter = 0;

        int nextDirectionChange = 0;

        public Enemy(PointF locationin) : base("Images/Enemy1.png", locationin)
        {
            Mainform.Enemylist.Add(this);
          
            isfiring = true;
            moveSpeed = 2;
            Walkdirection = 1;

            Random Randy = new Random((int)location.X);
            nextDirectionChange = Randy.Next(500) + 2000;
            currentweapon = new Pistol(location);
        }


        public override void Update(int time)
        {
            base.Update(time);

            directionChangeCounter += time;

              if (this.killed == true){
                Mainform.Points += 100;
                isfiring = false;
                Medkit m = new Medkit(this);
                Mainform.medlist.Add(m);
               // Console.WriteLine("Soilder" + ToString(this) )
                Mainform.Enemylist.Remove(this);
            }

              

            if (directionChangeCounter > nextDirectionChange) { 
            Random randy = new Random();
            facingAngle = randy.Next(360);

                directionChangeCounter = 0;

                nextDirectionChange = randy.Next(500) + 2000;
        }



        } 









    }
}
