﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace SharpShooter_Isaac.Game_Objects
{

	public class Wall
	{


		public int toppos; //the center of the top side?
		public int leftpos; //the center of the left side?

		public int width;
		public int height;



		public Bitmap image;
		//public string fileloc = "Images/";


		public Wall(String colour, int left, int top, int widthin, int heightin)
		{
			leftpos = left;
			toppos = top;
			width = widthin;
			height = heightin;
			image = new Bitmap("Images/" + colour + "Box.png"); //Orange or Green
			Mainform.wallist.Add(this);

		}


		public void draw(Graphics g)
		{

			g.Transform = new Matrix();
			g.DrawImage(image, new Rectangle(leftpos - Mainform.Voffset.X, toppos - Mainform.Voffset.Y, width, height));

		}

		public PointF nearest(PointF s)
		{

			PointF nearestpoint = new PointF();
			if (this.leftpos > s.X)
			{
				nearestpoint.X = this.leftpos;
			}else if (this.leftpos + this.width < s.X)
			{
				nearestpoint.X = this.leftpos + this.width;
			}
			else
			{
				nearestpoint.X = s.X;
			}


			if (this.toppos > s.Y)
			{
				nearestpoint.Y = this.toppos;

			}else if (this.toppos + this.height < s.Y)
			{
				nearestpoint.Y = this.toppos + this.height;
			}
			else
			{
				nearestpoint.Y = s.Y;
			}



			return nearestpoint;
		}


		public PointF normalatnearestpoint(PointF p)
		{
			PointF nearestpoint = nearest(p);
			PointF normal = new PointF();
			normal.X = p.X - nearestpoint.X;
			normal.Y = p.Y - nearestpoint.Y;



			if (normal.X == 0 && normal.Y == 0)
			{
				return normal;
			}

			float factor;

			factor = 1f/ (float)Math.Sqrt(normal.X*normal.X + normal.Y*normal.Y);

			normal.X *= factor;
			normal.Y *= factor;

			return normal;
		}
	}
	
}
