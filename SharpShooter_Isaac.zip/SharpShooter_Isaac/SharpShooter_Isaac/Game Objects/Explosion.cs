﻿using System;
using System.Collections.Generic;
using System.Deployment.Application;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpShooter_Isaac.Game_Objects.Weapons
{
    public class Explosion
    {
        //ka
        public  PointF location;
        public Picture pic;

        public int explotime = 440; //time for explosion

        public Explosion(PointF locationin)
        {
           
           
            pic = new Picture("Images/Explode.png", location, 6, 40);
            location = locationin; //set location
            Mainform.exlist.Add(this);
        }



        public virtual void draw(Graphics g)
        {
          
            pic.location.Y = location.Y - Mainform.Voffset.Y;
                pic.location.X = location.X - Mainform.Voffset.X;
            pic.Draw(g);
          
        }



        public void Update(int time)
        {
            explotime -= time;
            if (explotime <= 0)
            {
                Mainform.exlist.Remove(this); //remove from list
                return; //stop code
            }
            pic.update(time); //updates the pic
        }


        //BOOOM!
    }
}
