﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace SharpShooter_Isaac.Game_Objects
{
    public class Medkit
    {
        public Picture pic;
        public PointF location;
        public int radius;

        public Medkit(Soilder s)
        {
            location = s.location;
            pic = new Picture("Images/WeaponPickupHighlight.png", location, 1, 1);
            this.radius = pic.bitmap.Width / 2;
        }


        public void Draw(Graphics g)
        {
            pic.location.X = location.X - Mainform.Voffset.X;
            pic.location.Y = location.Y - Mainform.Voffset.Y;
            pic.Draw(g);
        }


        public void update(int time)
        {
            if (istouching(Mainform.player1))
            {
                if (Mainform.player1.hp < 10)
                {
                    Mainform.player1.hp = 10;
                }
                else
                {
                    Mainform.player1.hp += 10;
                }

                Mainform.medlist.Remove(this);
            }
        }


        public bool istouching(Soilder s)
        {
            float side1 = (s.location.X - this.location.X) * (s.location.X - this.location.X);
            float side2 = (s.location.Y - this.location.Y) * (s.location.Y - this.location.Y);

            double side3 = Math.Sqrt(side1 + side2);




            if (side3 < this.radius + s.radius)
            {
                Console.WriteLine("Hit soilder");
                return true;

            }
            else
            {
                //  Console.WriteLine("Checked istouching");
                return false;
            }
        }
    }
}
