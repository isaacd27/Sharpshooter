﻿using SharpShooter_Isaac.Game_Objects;
using SharpShooter_Isaac.Game_Objects.Weapons;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SharpShooter_Isaac
{
    public class Player : Soilder
    {
        

        public Player(PointF locationin) :base("Images/Player.png",locationin)
        {
            /* pic = new Picture("Images/Player_1.png", locationin);

             this.location = locationin;
             velocity = new PointF();*/

            currentweapon = new Pistol(this.location);
            this.hp = 10;



        }
        public void KeyDown(Object Sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left&&killed == false) {
                Turndirection = 1;
            }
            if (e.KeyCode == Keys.Right&&killed == false) {
                Turndirection = -1;
            }
            if (e.KeyCode == Keys.Up&&killed==false)
            {
                Walkdirection = 1;

            }
            if (e.KeyCode == Keys.Down&&killed==false)
            {
                Walkdirection = -1;
            }
            if (e.KeyCode == Keys.Space)
            {
                if (killed == false) {
                    isfiring = true;
                }

            }


        }


        public void KeyUp(Object Sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Right)
            {
                Turndirection = 0;
            } else if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Down)
            {
                Walkdirection = 0;
            } else if (e.KeyCode == Keys.Space)
            {
                isfiring = false;
            }
        }

    }
} 
