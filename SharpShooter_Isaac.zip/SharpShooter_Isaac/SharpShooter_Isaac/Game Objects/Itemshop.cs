﻿using SharpShooter_Isaac.Game_Objects.Weapons;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SharpShooter_Isaac.Game_Objects.Weapons;

namespace SharpShooter_Isaac.Game_Objects
{
    public partial class Itemshop : Form
    {
        public Mainform main;
        public Itemshop(Mainform mainf)
        {
            main = mainf;
            //medbay.Text = "Cost:10,000 ";
           
            
            InitializeComponent();
            Po.Text = "Points: " + Mainform.Points.ToString();
        }

    

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
           

        }

        private void sniperbuy_Click(object sender, EventArgs e)
        {
            if (Mainform.Points > 600)
            {
                Mainform.Points -= 600;
                Mainform.player1.currentweapon = new Sniper(Mainform.player1.location);
                buy.Text = "Thanks for purchasing!";
            }
            else
            {
                buy.Text = "Not enough points!";
            }
            
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void Rapidbuy_Click(object sender, EventArgs e)
        {
            if (Mainform.Points > 300)
            {
                Mainform.Points -= 300;
                Mainform.player1.currentweapon = new Rapid(Mainform.player1.location);
                buy.Text = "Thanks for purchasing!";
            }
            else
            {
                buy.Text = "Not Enough points!";
            }
           
        }

        private void Superbuy_Click(object sender, EventArgs e)
        {
            if(Mainform.Points > 30000)
            {
                Mainform.Points -= 30000;
                Mainform.player1.currentweapon = new Superlaunch(Mainform.player1.location);
                buy.Text = "Thanks for purchasing!";
            }
            else
            {
                buy.Text = "Not enough points!";
            }
            
        }

        private void medbuy_Click(object sender, EventArgs e)
        {
            if (Mainform.Points > 10000)
            {
                Mainform.Points -= 10000;
                Mainform.player1.hp += 10;
                buy.Text = "Thanks for purchasing!";
            }
            else
            {
                buy.Text = "Not enough points!";
            }
           
        }

        private void medbay_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
