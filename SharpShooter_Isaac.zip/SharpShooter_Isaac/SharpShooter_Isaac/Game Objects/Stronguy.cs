﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using SharpShooter_Isaac.Game_Objects.Weapons;

namespace SharpShooter_Isaac.Game_Objects
   
{
    public class Stronguy : Soilder
    {

        int directionChangeCounter = 0;

        int nextDirectionChange = 0; 


        public Stronguy(PointF locationin) : base("Images/Enemy3.png", locationin)
        {
            Mainform.Enemylist.Add(this);


            isfiring = true;
            moveSpeed = 1;
            Walkdirection = 1;
            hp = 15;
            Random Randy = new Random((int)location.X);
            nextDirectionChange = Randy.Next(500) + 2000;
            currentweapon = new Superlaunch(location);
        }


        public override void Update(int time)
        {
            base.Update(time);

            directionChangeCounter += time;

            if (this.killed == true)
            {
                Mainform.Points += 500;
                isfiring = false;
                Medkit m = new Medkit(this);
                Mainform.medlist.Add(m);
                // Console.WriteLine("Soilder" + ToString(this) )
                Mainform.Enemylist.Remove(this);
            }



            if (directionChangeCounter > nextDirectionChange)
            {
                Random randy = new Random();
                facingAngle = randy.Next(360);

                directionChangeCounter = 0;

                nextDirectionChange = randy.Next(500) + 2000;
            }



        }

    }
}
