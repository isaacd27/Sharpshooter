﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SharpShooter_Isaac.Game_Objects
{
    public class bullet
    {
        public Picture pic;
        public PointF location;
        public float facingangle;
        public float turndirection;
        public int godirection;
        public PointF velocity;
        public int movespeed = 15;
        public float life = 2f;
        public int radius;
        public int damage;
        Soilder parent; // tracks fireer

        public bullet(PointF locationin, Soilder soliderIn,String picin,int dam)
        {

            facingangle = (float) 0f;
            //pic = new Picture("Images/Bullet1.png",locationin,4,25);
            pic = new Picture(picin,locationin,4,25);
            location = locationin;
            velocity = new PointF();
            damage = dam;
            Mainform.bulletlist.Add(this);
            velocity.X = 15;
            radius = pic.bitmap.Width / 2;
            this.parent = soliderIn;
            //Console.WriteLine(picin);
        }


        public virtual void Move()
        {
            location.X += velocity.X;
            location.Y += velocity.Y;
        }


        public virtual void draw(Graphics g)
        {
            pic.Angle = facingangle;
            pic.location.X = location.X - Mainform.Voffset.X;
            pic.location.Y = location.Y - Mainform.Voffset.Y;
           // Console.WriteLine("drawed?");
            pic.Draw(g);
        }
        public void Update(int time)
        {
            


            //velocity.X = (float)Math.Cos(facingangle / 180f * Math.PI)  * movespeed;
            //velocity.Y = -(float)Math.Sin(facingangle / 180f * Math.PI)  * movespeed;

            Move();

            pic.update(time);
           // Console.WriteLine("pic updated");
            life -= (float)time / 1000f;
            //Player.timesincelastshot += time;
            if (life <= 0)
            {
                Mainform.bulletlist.Remove(this);
            }

            if (parent == Mainform.player1)
            {

                for (int i = 0; i < Mainform.Enemylist.Count; i++)
                {
                    if (this.isTouching(Mainform.Enemylist[i]))
                    {
                        
                        Mainform.Enemylist[i].damage(damage);
                        Mainform.bulletlist.Remove(this); //not armour pierceing
                       /* if (Mainform.Enemylist[i].killed == true){
                        Mainform.Enemylist.RemoveAt(i); // people die when they r killed
                        } */
                    }
                }
            }
            for (int i = 0; i < Mainform.Enemylist.Count; i++){
                     if (parent == Mainform.Enemylist[i]){
                if ((this.isTouching(Mainform.player1) && Mainform.player1.killed == false)){
                         Mainform.player1.damage(1);
                Mainform.bulletlist.Remove(this);
            }
               
                }
            
                        }


            foreach (Wall w in Mainform.wallist)
            {
                if (this.touchingwall(w))
                {
                    backthefup();
                    reflection(w.normalatnearestpoint(this.location));
                    
                }
            }

            
        }

        public bool isTouching(Soilder s)
        {

            float side1 = (s.location.X - this.location.X)* (s.location.X - this.location.X);
            float side2 = (s.location.Y - this.location.Y)* (s.location.Y - this.location.Y);

            double side3 = Math.Sqrt(side1 + side2);


            

            if (side3 < this.radius + s.radius) {
                //Console.WriteLine("Hit soilder");
                return true;
                
            } else {
              //  Console.WriteLine("Checked istouching");
                return false;
            }
        }




        public bool touchingwall(Wall w)
        {

            //Console.WriteLine("Wall touch");
            PointF p = w.nearest(this.location);

            float side1 = (p.X - this.location.X) * (p.X - this.location.X);
            float side2 = (p.Y - this.location.Y) * (p.Y - this.location.Y);

            float side3 = (float)Math.Sqrt(side1 + side2);

            if (side3 < this.radius)
            {
                backthefup();
                return true;
            }
            else
            {

                return false;
            }



        }


        public void backthefup()
        {
            this.location.X -= this.velocity.X;
            this.location.Y -= this.velocity.Y;
        }


        public void reflection(PointF normal)
        {
            PointF R = this.velocity;

            float b = (velocity.X* normal.X + velocity.Y * normal.Y);


            

            b *= 2;
            //R = I - 2b
            R = new PointF(this.velocity.X - normal.X * b, this.velocity.Y - normal.Y * b);
            //

            this.velocity.X = R.X;
            this.velocity.Y = R.Y;



        }





















    }
}
