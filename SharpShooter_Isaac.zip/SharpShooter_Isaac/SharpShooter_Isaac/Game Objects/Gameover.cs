﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static SharpShooter_Isaac.Mainform;
namespace SharpShooter_Isaac.Game_Objects
{
    public partial class Gameover : Form
    {
        public Mainform main;
        public Gameover(Mainform mainf)
        {
            main = mainf;
            InitializeComponent();
        }

        private void Gameover_Load(object sender, EventArgs e)
        {

        }

        private void Restart_Click(object sender, EventArgs e)
        {
            this.Hide();
          main.init();
        }

        private void Quit_Click(object sender, EventArgs e)
        {
            this.Hide();
            
            main.Quit = true;
        }
    }
}
