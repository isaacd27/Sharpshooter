﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading.Tasks;
using SharpShooter_Isaac.Game_Objects;

using SharpShooter_Isaac.Game_Objects.Weapons;
using System.Resources;

namespace SharpShooter_Isaac.Game_Objects
{
    public class level
    {

        public int width;
        public int height;
        public  PointF center;
       // public static List<bullet> bulletlist;

       // public static List<Soilder> Enemylist;
       // public static List<Wall> wallist;
       // public static List<Explosion> exlist;


        public level()
        {









        }


public static void InitalizeLists()
        {
            Mainform.bulletlist = new List<bullet>();
            Mainform.Enemylist = new List<Soilder>();
            Mainform.wallist = new List<Wall>();
            Mainform.exlist = new List<Explosion>();
            Mainform.weplist = new List<Weapon>();
            Mainform.medlist = new List<Medkit>();
        }

        public static void Createborders(int topx,int topY,int width,int height)
        {



            Wall borderTop = new Wall("Green", topx - 80, topY - 80, width + 80*2, 80);
            Wall borderLeft = new Wall("Orange", topx - 80, topY, 80, height + 80);
            Wall borderBotttom = new Wall("Green", topx, topY + height, width + 80, 80);
            Wall borderRight = new Wall("Orange",topx + width, topY - 80, 80, width + 80);

            
        }


        public static void createwalls()
        {
            Wall wall1 = new Wall("Blue", 150, 250, 300, 30);
            Wall wall2 = new Wall("Blue", 550, 250, 30, 350);
            Wall wall3 = new Wall("Blue", 50, 50, 30, 350);
            Wall wall4 = new Wall("Green", 650, 50, 50, 250);
            Wall wall5 = new Wall("Green", 750, 750, 70, 150);
            Wall wall6 = new Wall("Orange", 50, 50, 30, 30);
            Wall wall7 = new Wall("Orange", 450, 250, 100, 50);
            Wall wall8 = new Wall("Blue", -150, -250, 300, 30);
            Wall wall9 = new Wall("Blue", -550, -250, 30, 350);
            Wall wall10 = new Wall("Blue", -50, -50, 30, 350);
            Wall wall11 = new Wall("Green", -650, -50, 50, 250);
            Wall wall12 = new Wall("Green", -750, -750, 70, 150);
            Wall wall13 = new Wall("Orange", -50, -50, 30, 30);
            Wall wall14 = new Wall("Orange", -450, -250, 300, 30);
            Wall wall15 = new Wall("Blue", 0, 0, 10, 600);

        }

        public static void createenemies()
        {
            Enemy e1 = new Enemy(new PointF(550, 100));


            Enemy e2 = new Enemy(new PointF(450, 100));
            
            Enemy e3 = new Enemy(new PointF(550, 25));
            Enemy e4 = new Enemy(new PointF(650, 150));
            Enemy e5 = new Enemy(new PointF(740, 300));
            Enemy e6 = new Enemy(new PointF(-550, -100));
            Enemy e7 = new Enemy(new PointF(-450, -100));
            Enemy e8 = new Enemy(new PointF(-550, -25));
            Enemy e9 = new Enemy(new PointF(-650, -150));
            Enemy e10 = new Enemy(new PointF(-740, -300));
            Stronguy s1 = new Stronguy(new PointF(300, 300));
            Stronguy s2 = new Stronguy(new PointF(-300, -300));

            //800,-800
        }
        public static void createweapons()
        {
            Sniper s = new Sniper(new PointF(-500,500));
            s.onGround = true;

            Rapid r = new Rapid(new PointF(400,350));
            r.onGround = true;

            Superlaunch sup = new Superlaunch(new PointF(0, 0));
            sup.onGround = true;

            Mainform.weplist.Add(s);
            Mainform.weplist.Add(r);
            Mainform.weplist.Add(sup);

        }
        public static void createlevel()
        {
            Mainform.player1 = new Player(new PointF(500, 300));
            InitalizeLists();
                createwalls();
            createenemies();
            createweapons();
            Createborders(-800, -800,1600,1600);
            // about 1600 by 1600
            //center at 800,800
        }





    }
}
